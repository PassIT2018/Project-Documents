package com.pass.entertainment;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.ws.rs.core.MediaType;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pass.model.BadmintonFixures;
import com.pass.model.BadmintonResults;
import com.pass.restservice.RestWebService;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.WebResource;




/**
 * Handles requests for the application home page.
 */

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	List<String> tournamentYears = new ArrayList<String>();
	List<String> gamesList = new ArrayList<String>();
	
	
	String currentDate = "";

	@Autowired
	RestWebService webService ;
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView home(Locale locale, Model model) {
		
		ModelAndView modelView = new ModelAndView();
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG,locale);
		currentDate = dateFormat.format(date);
		
		
		
		modelView.setViewName("home");
		return modelView;
	}
	
	@RequestMapping(value = "/badminton", method = RequestMethod.GET)
	public ModelAndView badminton(Model model) {
		
		ModelAndView modelView = new ModelAndView();

		
		
		tournamentYears = webService.getTournamentYear();
		
		modelView.addObject("tournamentYears", tournamentYears);
		
		modelView.setViewName("badminton");
		return modelView;
	}
	
	@RequestMapping(value = "/volleyball", method = RequestMethod.GET)
	public ModelAndView volleyBall(Locale locale, Model model) {
		
		ModelAndView modelView = new ModelAndView();
		
		modelView.setViewName("volleyball");
		return modelView;
	}
	
	@RequestMapping(value = "/shortfilm", method = RequestMethod.GET)
	public ModelAndView shortFilm(Locale locale, Model model) {
		
		ModelAndView modelView = new ModelAndView();
		
		modelView.setViewName("shortfilm");
		return modelView;
	}
	@RequestMapping(value = "/moviereview", method = RequestMethod.GET)
	public ModelAndView movieReview(Locale locale, Model model) {
		
		
		ModelAndView modelView = new ModelAndView();
		
		modelView.setViewName("moviereview");
		return modelView;
	}
	
	@RequestMapping(value = "/badmintonfixures", method = RequestMethod.GET)
	public ModelAndView badmintonFixures(@RequestParam("year") String year,Locale locale, Model model) {
		
		List<BadmintonFixures> badmintonFixuresList = new ArrayList<BadmintonFixures> ();
		ModelAndView modelView = new ModelAndView();
		modelView.addObject("tournamentYears", tournamentYears);
		modelView.addObject("particularyear", year);
		
		badmintonFixuresList = webService.getBadmintonFixuresForTournamentYear(year);
		modelView.addObject("badmintonFixuresList", badmintonFixuresList);
		modelView.setViewName("badmintonfixures");
		return modelView;
	}
	

	
	@RequestMapping(value = "/badmintonresults", method = RequestMethod.GET)
	public ModelAndView badmintonResults(@RequestParam("year") String year,Locale locale, Model model) {
		
		List<BadmintonResults> badmintonResultsList = new ArrayList<BadmintonResults> ();
		ModelAndView modelView = new ModelAndView();
		modelView.addObject("tournamentYears", tournamentYears);
		modelView.addObject("particularyear", year);
		
		
		badmintonResultsList = webService.getBadmintonResultForTournamentYear(year);
		
		System.out.println("badminton result year:"+ year);
		modelView.addObject("badmintonResultsList",badmintonResultsList);
		modelView.setViewName("badmintonresults");
		return modelView;
	}
	
	@RequestMapping(value = "/contactus", method = RequestMethod.GET)
	public ModelAndView contactUs(Locale locale, Model model) {
		
		
		ModelAndView modelView = new ModelAndView();
		
		modelView.setViewName("contactus");
		return modelView;
	}
	
	@RequestMapping(value = "/contactus2", method = RequestMethod.GET)
	public ModelAndView contactUs2(Locale locale, Model model) {
		
		
		ModelAndView modelView = new ModelAndView();
		
		modelView.setViewName("contactus2");
		return modelView;
	}
	
	@RequestMapping(value = "/badmintonregistration", method = RequestMethod.GET)
	public ModelAndView badmintonRegistration(Locale locale, Model model) {
		
		
		ModelAndView modelView = new ModelAndView();
		
		modelView.setViewName("badmintonregistration");
		return modelView;
	}
	
}
