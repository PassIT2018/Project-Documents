package com.pass.model;

import java.io.Serializable;

public class Games implements Serializable {
	
	private String gameCode;
	private String gameName;
	
	public Games()
	{
		this.gameCode = "";
		this.gameName = "";
	}
	public Games(String gameCode, String gameName) {
		super();
		this.gameCode = gameCode;
		this.gameName = gameName;
	}
	public String getGameCode() {
		return gameCode;
	}
	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}
	public String getGameName() {
		return gameName;
	}
	public void setGameName(String gameName) {
		this.gameName = gameName;
	}
	@Override
	public String toString() {
		return "Games [gameCode=" + gameCode + ", gameName=" + gameName + "]";
	}
	
	
	

}
