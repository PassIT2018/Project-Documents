package com.pass.model;

import java.io.Serializable;
import java.sql.Time;
import java.util.Date;

public class BadmintonFixures  implements Serializable {
	
	private String tournamentYear;
	private String eventCode;
	private int matchNumber;
	private String teamName1;
	private String teamName2;
	private Date matchDate;
	private String matchTime;
	private String court;
	private String winner;
	
	public BadmintonFixures()
	{
		this.tournamentYear = "";
		this.eventCode = "";
		this.matchNumber = 0;
		this.teamName1 = "";
		this.teamName2 = "";
		this.matchDate = null;
		this.matchTime = null;
		this.court = "";
		this.winner = "";
	}
	public BadmintonFixures(String tournamentYear, String eventCode, int matchNumber, String teamName1,
			String teamName2, Date matchDate, String matchTime, String court, String winner) {
		super();
		this.tournamentYear = tournamentYear;
		this.eventCode = eventCode;
		this.matchNumber = matchNumber;
		this.teamName1 = teamName1;
		this.teamName2 = teamName2;
		this.matchDate = matchDate;
		this.matchTime = matchTime;
		this.court = court;
		this.winner = winner;
	}
	public String getTournamentYear() {
		return tournamentYear;
	}
	public void setTournamentYear(String tournamentYear) {
		this.tournamentYear = tournamentYear;
	}
	public String getEventCode() {
		return eventCode;
	}
	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}
	public int getMatchNumber() {
		return matchNumber;
	}
	public void setMatchNumber(int matchNumber) {
		this.matchNumber = matchNumber;
	}
	public String getTeamName1() {
		return teamName1;
	}
	public void setTeamName1(String teamName1) {
		this.teamName1 = teamName1;
	}
	public String getTeamName2() {
		return teamName2;
	}
	public void setTeamName2(String teamName2) {
		this.teamName2 = teamName2;
	}
	public Date getMatchDate() {
		return matchDate;
	}
	public void setMatchDate(Date matchDate) {
		this.matchDate = matchDate;
	}
	public String getMatchTime() {
		return matchTime;
	}
	public void setMatchTime(String matchTime) {
		this.matchTime = matchTime;
	}
	public String getCourt() {
		return court;
	}
	public void setCourt(String court) {
		this.court = court;
	}
	public String getWinner() {
		return winner;
	}
	public void setWinner(String winner) {
		this.winner = winner;
	}
	@Override
	public String toString() {
		return "BadmintonFixures [tournamentYear=" + tournamentYear + ", eventCode=" + eventCode + ", matchNumber="
				+ matchNumber + ", teamName1=" + teamName1 + ", teamName2=" + teamName2 + ", matchDate=" + matchDate
				+ ", matchTime=" + matchTime + ", court=" + court + ", winner=" + winner + "]";
	}
	
	

}
