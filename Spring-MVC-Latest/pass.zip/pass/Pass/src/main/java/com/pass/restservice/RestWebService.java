package com.pass.restservice;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MediaType;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pass.model.BadmintonFixures;
import com.pass.model.BadmintonResults;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class RestWebService {
	
	
	public List<String> getTournamentYear()
	{
		List<String> tournamentYears = new ArrayList<String>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getBadmintonTournamentYears";
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
		
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			tournamentYears = mapper.readValue(webServiceData, new TypeReference<List<String>>() {});
			
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return tournamentYears;
		
	}
	
	public List<String> getAllGames()
	{
		List<String> gamesList = new ArrayList<String>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getAllGames";
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
		
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			gamesList = mapper.readValue(webServiceData, new TypeReference<List<String>>() {});
			
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return gamesList;
		
	}
	
	public List<BadmintonResults> getBadmintonResultForTournamentYear(String tournamentYear)
	{
		List<BadmintonResults> badmintonResultsList = new ArrayList<BadmintonResults>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getBadmintonResults/"+tournamentYear;
		System.out.println("url:"+url);
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
	
		
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			badmintonResultsList = mapper.readValue(webServiceData, new TypeReference<List<BadmintonResults>>() {});
			
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return badmintonResultsList;
		
	}
	
	public List<BadmintonFixures> getBadmintonFixuresForTournamentYear(String tournamentYear)
	{
		List<BadmintonFixures> badmintonFixuresList = new ArrayList<BadmintonFixures>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getBadmintonFixures/"+tournamentYear;
		System.out.println("url:"+url);
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
	
		
		ObjectMapper mapper = new ObjectMapper();
		
		try {
			badmintonFixuresList = mapper.readValue(webServiceData, new TypeReference<List<BadmintonFixures>>() {});
			
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return badmintonFixuresList;
		
	}

}
