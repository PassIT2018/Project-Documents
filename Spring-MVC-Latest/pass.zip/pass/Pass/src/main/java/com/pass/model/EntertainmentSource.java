package com.pass.model;

import java.io.Serializable;

public class EntertainmentSource implements Serializable{
	
	private int serialNumber;
	private String entertainmentSrcYear;
	private String entertainmentCode;
	private String entertainmentSrcLink;
	private int entertainmentOrderDisplay;
	
	
	public EntertainmentSource()
	{
		this.serialNumber = 0;
		this.entertainmentCode = "";
		this.entertainmentSrcYear = "";
		this.entertainmentSrcLink = "";
		this.entertainmentOrderDisplay = 0;
	}
	public EntertainmentSource(int serialNumber, String entertainmentSrcYear, String entertainmentCode,
			String entertainmentSrcLink, int entertainmentOrderDisplay) {
		super();
		this.serialNumber = serialNumber;
		this.entertainmentSrcYear = entertainmentSrcYear;
		this.entertainmentCode = entertainmentCode;
		this.entertainmentSrcLink = entertainmentSrcLink;
		this.entertainmentOrderDisplay = entertainmentOrderDisplay;
	}
	public int getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getEntertainmentSrcYear() {
		return entertainmentSrcYear;
	}
	public void setEntertainmentSrcYear(String entertainmentSrcYear) {
		this.entertainmentSrcYear = entertainmentSrcYear;
	}
	public String getEntertainmentCode() {
		return entertainmentCode;
	}
	public void setEntertainmentCode(String entertainmentCode) {
		this.entertainmentCode = entertainmentCode;
	}
	public String getEntertainmentSrcLink() {
		return entertainmentSrcLink;
	}
	public void setEntertainmentSrcLink(String entertainmentSrcLink) {
		this.entertainmentSrcLink = entertainmentSrcLink;
	}
	public int getEntertainmentOrderDisplay() {
		return entertainmentOrderDisplay;
	}
	public void setEntertainmentOrderDisplay(int entertainmentOrderDisplay) {
		this.entertainmentOrderDisplay = entertainmentOrderDisplay;
	}
	@Override
	public String toString() {
		return "EntertainmentSource [serialNumber=" + serialNumber + ", entertainmentSrcYear=" + entertainmentSrcYear
				+ ", entertainmentCode=" + entertainmentCode + ", entertainmentSrcLink=" + entertainmentSrcLink
				+ ", entertainmentOrderDisplay=" + entertainmentOrderDisplay + "]";
	}
	
	
	

}
