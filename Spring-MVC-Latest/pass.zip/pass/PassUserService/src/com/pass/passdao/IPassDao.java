package com.pass.passdao;


import java.util.List;

import com.pass.model.BadmintonFixures;
import com.pass.model.BadmintonResults;
import com.pass.model.ContactUs;
import com.pass.model.Entertainment;
import com.pass.model.EntertainmentSource;
import com.pass.model.Games;
import com.pass.model.RegisterBadminton;

public interface IPassDao {
	
	
	public boolean insertContactUs(ContactUs contactUs);
	public boolean registerBadminton(RegisterBadminton registerBadminton);
	public RegisterBadminton getBadmintonRegistration(String registationNo);
	public boolean updateBadmintonRegistration(RegisterBadminton registerBadminton);
	public boolean validateTeamName(String teamName);
	public List<BadmintonResults> getBadmintonResults(String tournamentYear);
	public List<BadmintonResults> getAllBadmintonResults();
	public List<BadmintonFixures> getBadmintonFixures(String tournamentYear);
	public List<BadmintonFixures> getAllBadmintonFixures();
	public List<Games> getAllGames();
	public List<String> getBadmintonEventTournamentYears();
	public List<Entertainment> getAllEntertainments();
	public List<EntertainmentSource> getAllEntertainmentSource(String entertainmentCode);
	
	
	
	
	

}
