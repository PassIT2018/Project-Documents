package com.pass.passdao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.pass.model.BadmintonFixures;
import com.pass.model.BadmintonResults;
import com.pass.model.ContactUs;
import com.pass.model.Entertainment;
import com.pass.model.EntertainmentSource;
import com.pass.model.Games;
import com.pass.model.RegisterBadminton;

public class PassImpDao implements IPassDao {


	@Override
	public boolean insertContactUs(ContactUs contactUs) {
		
		boolean insertFlag = false;
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();
			String sql="insert into contact_us values(nextval('contact_us_seq'),?,?,?,?,?)";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			prepareStatement.setString(1, contactUs.getContactName());
			prepareStatement.setString(2, contactUs.getEmail());
			prepareStatement.setString(3, contactUs.getPhone());
			prepareStatement.setString(4, contactUs.getMessage());
			prepareStatement.setDate(5,(Date) contactUs.getDateInserted());
			int insrtCnt = prepareStatement.executeUpdate();
			
			if (insrtCnt > 0 )
			{
				insertFlag = true;
			}
			
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return insertFlag;
	}

	@Override
	public boolean registerBadminton(RegisterBadminton registerBadminton) {
		boolean insertFlag = false;
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();
			
			String sql = "insert into badminton_registration values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			
			prepareStatement.setString(1,registerBadminton.getTournamentYear());
			prepareStatement.setString(2,registerBadminton.getRegistrationNo());
			prepareStatement.setString(3,registerBadminton.getTeamName());
			prepareStatement.setString(4,registerBadminton.getName());
			prepareStatement.setDate(5, (Date) registerBadminton.getDob());
			prepareStatement.setString(6,registerBadminton.getEmail());
			prepareStatement.setString(7,registerBadminton.getPhone());
			prepareStatement.setString(8,registerBadminton.getEventCode());
			prepareStatement.setString(9,registerBadminton.getPartnerName());
			prepareStatement.setDate(10, (Date) registerBadminton.getPartnerDOB());
			prepareStatement.setDouble(11,registerBadminton.getPayementAmount());
			prepareStatement.setString(12,registerBadminton.getGameCode());
			prepareStatement.setDate(13, (Date) registerBadminton.getDateInserted());
			prepareStatement.setDate(14, (Date) registerBadminton.getDateUpdated());
			
			int insrtcnt = prepareStatement.executeUpdate();
			
			if(insrtcnt > 0)
			{
				insertFlag = true;
			}
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return insertFlag;
	}

	@Override
	public boolean updateBadmintonRegistration(RegisterBadminton registerBadminton) {
		boolean updateFlag = false;
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();
			
			String sql = "update badminton_registration set name = ? , dob = ? , email = ? , phone = ?"
					+ "event_code = ? , partner_name = ?, partner_dob = ? ,date_updated = ? where"
					+ "registration_number = ?";
			
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			
			
			prepareStatement.setString(4,registerBadminton.getName());
			prepareStatement.setDate(5, (Date) registerBadminton.getDob());
			prepareStatement.setString(6,registerBadminton.getEmail());
			prepareStatement.setString(7,registerBadminton.getPhone());
			prepareStatement.setString(8,registerBadminton.getEventCode());
			prepareStatement.setString(9,registerBadminton.getPartnerName());
			prepareStatement.setDate(10, (Date) registerBadminton.getPartnerDOB());
			prepareStatement.setDate(14, (Date) registerBadminton.getDateUpdated());
			
			int updatecnt = prepareStatement.executeUpdate();
			
			if(updatecnt > 0)
			{
				updateFlag = true;
			}
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return updateFlag;
	}

	
	@Override
	public boolean validateTeamName(String teamName) {
		boolean validTeamFlag = false;
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select team_name from badminton_registration where team_name = ?";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			prepareStatement.setString(1,teamName);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			if(resultSet.next())
			{
				validTeamFlag = true;
			}
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return validTeamFlag;
	}

	@Override
	public RegisterBadminton getBadmintonRegistration(String registrationNo) {
		RegisterBadminton registerBadminton = new RegisterBadminton();
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select tournament_year,registration_number,team_name,name,dob,"
					+ "email,phone,event_code,partner_name,partner_dob,payment_amount,game_code,"
					+ "date_inserted,date_updated from badminton_registration where registration_number = ?";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			prepareStatement.setString(1,registrationNo);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				
				registerBadminton.setTournamentYear(resultSet.getString(1));
				registerBadminton.setRegistrationNo(resultSet.getString(2));
				registerBadminton.setTeamName(resultSet.getString(3));
				registerBadminton.setName(resultSet.getString(4));
				registerBadminton.setDob(convertSqlDateToUtilDate(resultSet.getDate(5)));
				registerBadminton.setEmail(resultSet.getString(6));
				registerBadminton.setPhone(resultSet.getString(7));
				registerBadminton.setEventCode(resultSet.getString(8));
				registerBadminton.setPartnerName(resultSet.getString(9));
				registerBadminton.setPartnerDOB(convertSqlDateToUtilDate(resultSet.getDate(10)));
				registerBadminton.setPayementAmount(resultSet.getDouble(11));
				registerBadminton.setGameCode(resultSet.getString(12));
				registerBadminton.setDateInserted(convertSqlDateToUtilDate(resultSet.getDate(13)));
				registerBadminton.setDateUpdated(convertSqlDateToUtilDate(resultSet.getDate(14)));
				
				
			}
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return registerBadminton;
	}

	@Override
	public List<BadmintonResults> getBadmintonResults(String tournamentYear) {
		
		List<BadmintonResults> badmintonResultList = new ArrayList<BadmintonResults>();
		
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select tournament_year,event_code,position,team_name,"
					+ "team_player1,team_player2,game_code from badminton_results where tournament_year =  ?"
					+ "order by serial_number asc";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			prepareStatement.setString(1,tournamentYear);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				BadmintonResults badmintonResults = new BadmintonResults();
				badmintonResults.setTournamentYear(resultSet.getString(1));
				badmintonResults.setEventCode(resultSet.getString(2));
				badmintonResults.setPosition(resultSet.getString(3));
				badmintonResults.setTeamName(resultSet.getString(4));
				badmintonResults.setPlayerName1(resultSet.getString(5));
				badmintonResults.setPlayerName2(resultSet.getString(6));
				badmintonResults.setGameCode(resultSet.getString(7));
				
				badmintonResultList.add(badmintonResults);
			}
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return badmintonResultList;
	}

	@Override
	public List<BadmintonResults> getAllBadmintonResults() {
		List<BadmintonResults> badmintonResultsList = new ArrayList<BadmintonResults>();
		
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select tournament_year,event_code,position,team_name,"
					+ "team_player1,team_player2,game_code  from badminton_results"
					+ "order by serial_number asc";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				BadmintonResults badmintonResults = new BadmintonResults();
				badmintonResults.setTournamentYear(resultSet.getString(1));
				badmintonResults.setEventCode(resultSet.getString(2));
				badmintonResults.setPosition(resultSet.getString(3));
				badmintonResults.setTeamName(resultSet.getString(4));
				badmintonResults.setPlayerName1(resultSet.getString(5));
				badmintonResults.setPlayerName2(resultSet.getString(6));
				badmintonResults.setGameCode(resultSet.getString(7));
				
				badmintonResultsList.add(badmintonResults);
			}
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return badmintonResultsList;
	}

	@Override
	public List<BadmintonFixures> getBadmintonFixures(String tournamentYear) {
		List<BadmintonFixures> badmintonFixuresList = new ArrayList<BadmintonFixures>();
		
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select tournament_year,event_code,match_number,team_name1,"
					+ "team_name2,match_date,match_time,court,winner from badminton_fixures where tournament_year =  ?"
					+ "order by tournament_year asc";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			prepareStatement.setString(1,tournamentYear);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				BadmintonFixures badmintonFixures = new BadmintonFixures();
				
				badmintonFixures.setTournamentYear(resultSet.getString(1));
				badmintonFixures.setEventCode(resultSet.getString(2));
				badmintonFixures.setMatchNumber(resultSet.getInt(3));
				badmintonFixures.setTeamName1(resultSet.getString(4));
				badmintonFixures.setTeamName2(resultSet.getString(5));
				badmintonFixures.setMatchDate(convertSqlDateToUtilDate(resultSet.getDate(6)));
				badmintonFixures.setMatchTime(resultSet.getString(7));
				badmintonFixures.setCourt(resultSet.getString(8));
				badmintonFixures.setWinner(resultSet.getString(9));
				
				badmintonFixuresList.add(badmintonFixures);
			}
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		for(BadmintonFixures s : badmintonFixuresList)
		{
			System.out.println("fixures:"+s.toString());
		}
		return badmintonFixuresList;
	}

	@Override
	public List<BadmintonFixures> getAllBadmintonFixures() {
		
		List<BadmintonFixures> badmintonFixuresList = new ArrayList<BadmintonFixures>();
		
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select tournament_year,event_code,match_number,team_name1,"
					+ "team_name2,match_date,match_time,court,winner "
					+ " from badminton_fixures order by tournement_year asc";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				BadmintonFixures badmintonFixures = new BadmintonFixures();
				badmintonFixures.setTournamentYear(resultSet.getString(1));
				badmintonFixures.setEventCode(resultSet.getString(2));
				badmintonFixures.setMatchNumber(resultSet.getInt(3));
				badmintonFixures.setTeamName1(resultSet.getString(4));
				badmintonFixures.setTeamName2(resultSet.getString(5));
				badmintonFixures.setMatchDate(convertSqlDateToUtilDate(resultSet.getDate(6)));
				badmintonFixures.setMatchTime(resultSet.getString(7));
				badmintonFixures.setCourt(resultSet.getString(8));
				badmintonFixures.setWinner(resultSet.getString(9));
				
				badmintonFixuresList.add(badmintonFixures);
			}
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return badmintonFixuresList;
	}

	@Override
	public List<Games> getAllGames() {
		List<Games> gamesList = new ArrayList<Games>();
		
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();	
			
			String sql = "select game_code,game_name from games";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				Games games = new Games();
				games.setGameCode(resultSet.getString(1));
				games.setGameName(resultSet.getString(2));
				
				
				gamesList.add(games);
			}
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return gamesList;
	}

	

	@Override
	public List<String> getBadmintonEventTournamentYears() {
		List<String> badmintonYearList = new ArrayList<String>();
		
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select distinct(tournament_year) from badminton_events order by tournament_year desc";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
	
				
				badmintonYearList.add(resultSet.getString(1));
				
			}
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return badmintonYearList;
	}

	
	
public static  java.util.Date convertSqlDateToUtilDate(java.sql.Date sqlDate)
{
	java.util.Date utilDate = null;
	if (sqlDate != null)
	{
		
		utilDate = new java.util.Date(sqlDate.getTime());
		
	}
	
	return utilDate;
	
}

@Override
public List<Entertainment> getAllEntertainments() {
	List<Entertainment> entertainmentList = new ArrayList<Entertainment>();
	
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "select entertainment_code,entertainment_name from entertainment";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		ResultSet resultSet = prepareStatement.executeQuery();
		
		while(resultSet.next())
		{
			Entertainment entertainment = new Entertainment();
			entertainment.setEntertainmentCode(resultSet.getString(1));
			entertainment.setEntertainmentName(resultSet.getString(2));
			
			
			entertainmentList.add(entertainment);
		}
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return entertainmentList;
}

@Override
public List<EntertainmentSource> getAllEntertainmentSource(String entertainmentCode) {
	List<EntertainmentSource> entertainmentSourceList = new ArrayList<EntertainmentSource>();
	
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "select serial_number,entertainment_src_year,entertainment_code,entertainment_src_link,"
				+ "entertainment_display_order from entertainment_source "
				+ "where entertainment_code = ? order by entertainment_display_order asc";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(1,entertainmentCode);
		ResultSet resultSet = prepareStatement.executeQuery();
		
		while(resultSet.next())
		{
			
			
			entertainmentSourceList.add(new EntertainmentSource(resultSet.getInt(1),
															   resultSet.getString(2),
															   resultSet.getString(3),
															   resultSet.getString(4),
															   resultSet.getInt(5)));
		}
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return entertainmentSourceList;
}
	
}
