package com.pass.model;

import java.io.Serializable;

public class Entertainment implements Serializable{
	
	
	private String entertainmentCode;
	private String entertainmentName;
	
	public Entertainment()
	{
		this.entertainmentCode = "";
		this.entertainmentName = "";
	}
	public Entertainment(String entertainmentCode, String entertainmentName) {
		super();
		this.entertainmentCode = entertainmentCode;
		this.entertainmentName = entertainmentName;
	}
	public String getEntertainmentCode() {
		return entertainmentCode;
	}
	public void setEntertainmentCode(String entertainmentCode) {
		this.entertainmentCode = entertainmentCode;
	}
	public String getEntertainmentName() {
		return entertainmentName;
	}
	public void setEntertainmentName(String entertainmentName) {
		this.entertainmentName = entertainmentName;
	}
	@Override
	public String toString() {
		return "Entertainment [entertainmentCode=" + entertainmentCode + ", entertainmentName=" + entertainmentName
				+ "]";
	}
	
	

}
