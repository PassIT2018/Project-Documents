package com.pass.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import java.sql.*;

import com.pass.model.BadmintonFixures;
import com.pass.model.BadmintonResults;
import com.pass.model.ContactUs;
import com.pass.model.Entertainment;
import com.pass.model.EntertainmentSource;
import com.pass.model.Games;
import com.pass.model.RegisterBadminton;
import com.pass.passdao.PassImpDao;

@Path("/PassService")
public class PassService {
	
	PassImpDao passDao = new PassImpDao();
	
	@POST
	@Path("/insertContactUs")
	@Produces(MediaType.TEXT_PLAIN)
	public String insertContactUs(ContactUs contactUs)
	{				
		boolean insertFlag = false;
		String booleanResponse = Boolean.FALSE.toString();
		contactUs.setDateInserted(this.convertToSqlDate(this.getCurrentDate()));
		insertFlag = passDao.insertContactUs(contactUs);
		if(insertFlag)
		{
			booleanResponse = Boolean.TRUE.toString();
		}
		
		return booleanResponse;		
	}
	
	@POST
	@Path("/registerBadminton")
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_JSON)
	public String registerBadminton(RegisterBadminton registerBadminton)
	{
		boolean insertFlag = false;
		String booleanResponse = Boolean.FALSE.toString();
		insertFlag = passDao.registerBadminton(registerBadminton);
		if(insertFlag)
		{
			booleanResponse = Boolean.TRUE.toString();
		}
		
		return booleanResponse;	
		
	}
	
	
	@GET
	@Path("/getBadmintonRegistration/{registrationNo}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.TEXT_PLAIN)
	public RegisterBadminton getBadmintonRegistration(@PathParam("registrationNo") String registrationNo)
	{
		System.out.println("registration no:"+ registrationNo);
		RegisterBadminton registerBadminton = new RegisterBadminton();
		registerBadminton = passDao.getBadmintonRegistration(registrationNo);
		return registerBadminton;
		
	}
	
	@POST
	@Path("/updateBadmintonRegistration")
	@Produces(MediaType.TEXT_PLAIN)
	@Consumes(MediaType.APPLICATION_JSON)
	public String updateBadmintonRegistration(RegisterBadminton registerBadminton)
	{
		boolean updateFlag = false;
		String booleanResponse = Boolean.FALSE.toString();
		updateFlag = passDao.updateBadmintonRegistration(registerBadminton);
		if(updateFlag)
		{
			booleanResponse = Boolean.TRUE.toString();
		}
		
		return booleanResponse;	
		
	}
	
	@GET
	@Path("/validateTeamName/{teamName}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public String validateTeamName(@PathParam("teamName") String teamName)
	{
		boolean validTeamFlag = false;
		String booleanResponse = Boolean.FALSE.toString();
		validTeamFlag = passDao.validateTeamName(teamName);
		if(validTeamFlag)
		{
			booleanResponse = Boolean.TRUE.toString();
		}
		
		return booleanResponse;	
	}
	
	@GET
	@Path("/getBadmintonResults/{tournamentYear}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.TEXT_PLAIN)
	public List<BadmintonResults> getBadmintonResults(@PathParam("tournamentYear") String tournamentYear)
	{
		
		List<BadmintonResults> badmintonResults = new ArrayList<BadmintonResults>();
		badmintonResults = passDao.getBadmintonResults(tournamentYear);
		
		return badmintonResults;
	}
	
	@GET
	@Path("/getAllBadmintonResults")
	@Produces(MediaType.APPLICATION_JSON)
	public List<BadmintonResults> getAllBadmintonResults()
	{
		List<BadmintonResults> badmintonResultsList = new ArrayList<BadmintonResults>();
		badmintonResultsList = passDao.getAllBadmintonResults();
		return badmintonResultsList;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.TEXT_PLAIN)
	@Path("/getBadmintonFixures/{tournamentYear}")
	public List<BadmintonFixures> getBadmintonFixures(@PathParam("tournamentYear") String tournamentYear)
	{
		List<BadmintonFixures> badmintonFixures = new ArrayList<BadmintonFixures>();
		badmintonFixures = passDao.getBadmintonFixures(tournamentYear);
		return badmintonFixures;
	}
	
	@GET
	@Path("/getAllBadmintonFixures")
	@Produces(MediaType.APPLICATION_JSON)
	public List<BadmintonFixures> getAllBadmintonFixures()
	{
		List<BadmintonFixures> badmintonFixuresList = new ArrayList<BadmintonFixures> ();
		badmintonFixuresList = passDao.getAllBadmintonFixures();
		return badmintonFixuresList;
	}
	
	@GET
    @Produces(MediaType.APPLICATION_JSON)
	@Path("/getAllGames")
	public List<Games> getAllGames()
	{
		List<Games> gamesList = new ArrayList<Games> ();
		gamesList = passDao.getAllGames();
		return gamesList;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getBadmintonTournamentYears")
	public List<String> getBadmintonEventTournamentYears()
	{
		List<String> badmintonYearList = new ArrayList<String> ();
		badmintonYearList = passDao.getBadmintonEventTournamentYears();	
		return badmintonYearList;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getEntertainment")
	public List<Entertainment> getAllEntertainment()
	{
		List<Entertainment> entertainmentList = new ArrayList<Entertainment> ();
		entertainmentList = passDao.getAllEntertainments();	
		return entertainmentList;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getEntertainmentSource")
	@Consumes(MediaType.TEXT_PLAIN)
	public List<EntertainmentSource> getAllEntertainmentSource(String entertainmentCode)
	{
		List<EntertainmentSource> entertainmentSourceList = new ArrayList<EntertainmentSource> ();
		entertainmentSourceList = passDao.getAllEntertainmentSource(entertainmentCode);	
		return entertainmentSourceList;
	}
	
	// This method is used for returning the current date
	public Date getCurrentDate()
	{
		Date currentDate = null;		
		try {
			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			currentDate = new SimpleDateFormat("dd-MM-yyyy").parse(dateFormat.format(new Date()));
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return currentDate;
		
	}
	
	//This method is used for converting the util.date to sql.date
	public java.sql.Date convertToSqlDate(Date currentDate)
	{
		java.sql.Date sqlDate = new java.sql.Date(currentDate.getTime());
		return sqlDate;
	}
	

}
