package com.pass.model;

import java.io.Serializable;

public class EntertainmentSource implements Serializable{
	
	private int serialNumber;
	private String entertainmentSrcYear;
	private String entertainmentCode;
	private String entertainmentSrcLink;
	private int entertainmentOrderDisplay;
	private String actorName;
	private String critisRating;
	private String  userRating;
	private String language;
	private String category;
	private String releaseDate;
	private String entertainmentName;
	
	
	public EntertainmentSource()
	{
		this.serialNumber = 0;
		this.entertainmentCode = "";
		this.entertainmentSrcYear = "";
		this.entertainmentSrcLink = "";
		this.entertainmentOrderDisplay = 0;
		this.actorName = "";
		this.releaseDate = "";
		this.language = "";
		this.category = "";
		this.critisRating = "";
		this.userRating = "";
		this.entertainmentName = "";
		
		
		
	}


	public EntertainmentSource(int serialNumber, String entertainmentSrcYear, String entertainmentCode,
			String entertainmentSrcLink, int entertainmentOrderDisplay, String actorName, String critisRating,
			String userRating, String language, String category, String releaseDate, String entertainmentName) {
		super();
		this.serialNumber = serialNumber;
		this.entertainmentSrcYear = entertainmentSrcYear;
		this.entertainmentCode = entertainmentCode;
		this.entertainmentSrcLink = entertainmentSrcLink;
		this.entertainmentOrderDisplay = entertainmentOrderDisplay;
		this.actorName = actorName;
		this.critisRating = critisRating;
		this.userRating = userRating;
		this.language = language;
		this.category = category;
		this.releaseDate = releaseDate;
		this.entertainmentName = entertainmentName;
	}


	public int getSerialNumber() {
		return serialNumber;
	}


	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}


	public String getEntertainmentSrcYear() {
		return entertainmentSrcYear;
	}


	public void setEntertainmentSrcYear(String entertainmentSrcYear) {
		this.entertainmentSrcYear = entertainmentSrcYear;
	}


	public String getEntertainmentCode() {
		return entertainmentCode;
	}


	public void setEntertainmentCode(String entertainmentCode) {
		this.entertainmentCode = entertainmentCode;
	}


	public String getEntertainmentSrcLink() {
		return entertainmentSrcLink;
	}


	public void setEntertainmentSrcLink(String entertainmentSrcLink) {
		this.entertainmentSrcLink = entertainmentSrcLink;
	}


	public int getEntertainmentOrderDisplay() {
		return entertainmentOrderDisplay;
	}


	public void setEntertainmentOrderDisplay(int entertainmentOrderDisplay) {
		this.entertainmentOrderDisplay = entertainmentOrderDisplay;
	}


	public String getActorName() {
		return actorName;
	}


	public void setActor_name(String actorName) {
		this.actorName = actorName;
	}


	public String getCritisRating() {
		return critisRating;
	}


	public void setCritisRating(String critisRating) {
		this.critisRating = critisRating;
	}


	public String getUserRating() {
		return userRating;
	}


	public void setUserRating(String userRating) {
		this.userRating = userRating;
	}


	public String getLanguage() {
		return language;
	}


	public void setLanguage(String language) {
		this.language = language;
	}


	public String getCategory() {
		return category;
	}


	public void setCategory(String category) {
		this.category = category;
	}


	public String getReleaseDate() {
		return releaseDate;
	}


	public void setReleaseDate(String releaseDate) {
		this.releaseDate = releaseDate;
	}


	public String getEntertainmentName() {
		return entertainmentName;
	}


	public void setEntertainmentName(String entertainmentName) {
		this.entertainmentName = entertainmentName;
	}


	@Override
	public String toString() {
		return "EntertainmentSource [serialNumber=" + serialNumber + ", entertainmentSrcYear=" + entertainmentSrcYear
				+ ", entertainmentCode=" + entertainmentCode + ", entertainmentSrcLink=" + entertainmentSrcLink
				+ ", entertainmentOrderDisplay=" + entertainmentOrderDisplay + ", actorName=" + actorName
				+ ", critisRating=" + critisRating + ", userRating=" + userRating + ", language=" + language
				+ ", category=" + category + ", releaseDate=" + releaseDate + ", entertainmentName="
				+ entertainmentName + "]";
	}
	
	
	

}
