package com.pass.service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.json.JsonObject;
import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;



import java.sql.*;


import com.pass.model.BadmintonEventFixures;
import com.pass.model.BadmintonEventResults;
import com.pass.model.BadmintonEvents;
import com.pass.model.BadmintonFixures;
import com.pass.model.BadmintonResults;
import com.pass.model.ContactUs;
import com.pass.model.DistinctBadmintonEvent;
import com.pass.model.Entertainment;
import com.pass.model.EntertainmentSource;
import com.pass.model.Games;
import com.pass.model.OutputMessage;
import com.pass.model.PasswordReset;
import com.pass.model.RegisterBadminton;
import com.pass.model.UserInfo;
import com.pass.passdao.PassImpDao;

@Path("/PassService")
public class PassService {
	
	
	
	PassImpDao passDao = new PassImpDao();
	
	@POST
	@Path("/insertContactUs")
	@Produces(MediaType.TEXT_PLAIN)
	public String insertContactUs(ContactUs contactUs)
	{				
		boolean insertFlag = false;
		String booleanResponse = Boolean.FALSE.toString();
		contactUs.setDateInserted(this.convertToSqlDate(this.getCurrentDate()));
		insertFlag = passDao.insertContactUs(contactUs);
		if(insertFlag)
		{
			booleanResponse = Boolean.TRUE.toString();
		}
		
		return booleanResponse;		
	}
	
	@POST
	@Path("/registerBadminton")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage registerBadminton(RegisterBadminton registerBadminton)
	{
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.registerBadminton(registerBadminton);
		return outputMessage;	
		
	}
	
	
	@GET
	@Path("/getBadmintonRegistration/{registrationNo}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.TEXT_PLAIN)
	public RegisterBadminton getBadmintonRegistration(@PathParam("registrationNo") String registrationNo)
	{
		System.out.println("registration no:"+ registrationNo);
		RegisterBadminton registerBadminton = new RegisterBadminton();
		registerBadminton = passDao.getBadmintonRegistration(registrationNo);
		return registerBadminton;
		
	}
	
	@POST
	@Path("/updateBadmintonRegistration")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage updateBadmintonRegistration(RegisterBadminton registerBadminton)
	{
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.updateBadmintonRegistration(registerBadminton);
		return outputMessage;	
		
	}
	
	@GET
	@Path("/validateTeamName/{teamName}")
	@Consumes(MediaType.TEXT_PLAIN)
	@Produces(MediaType.TEXT_PLAIN)
	public String validateTeamName(@PathParam("teamName") String teamName)
	{
		boolean validTeamFlag = false;
		String booleanResponse = Boolean.FALSE.toString();
		validTeamFlag = passDao.validateTeamName(teamName);
		if(validTeamFlag)
		{
			booleanResponse = Boolean.TRUE.toString();
		}
		
		return booleanResponse;	
	}
	
	@GET
	@Path("/getBadmintonResults/{tournamentYear}")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.TEXT_PLAIN)
	public List<BadmintonResults> getBadmintonResults(@PathParam("tournamentYear") String tournamentYear)
	{
		
		List<BadmintonResults> badmintonResults = new ArrayList<BadmintonResults>();
		badmintonResults = passDao.getBadmintonResults(tournamentYear);
		
		return badmintonResults;
	}
	
	@GET
	@Path("/getAllBadmintonResults")
	@Produces(MediaType.APPLICATION_JSON)
	public List<BadmintonResults> getAllBadmintonResults()
	{
		List<BadmintonResults> badmintonResultsList = new ArrayList<BadmintonResults>();
		badmintonResultsList = passDao.getAllBadmintonResults();
		return badmintonResultsList;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.TEXT_PLAIN)
	@Path("/getBadmintonFixures/{tournamentYear}")
	public List<BadmintonFixures> getBadmintonFixures(@PathParam("tournamentYear") String tournamentYear)
	{
		List<BadmintonFixures> badmintonFixures = new ArrayList<BadmintonFixures>();
		badmintonFixures = passDao.getBadmintonFixures(tournamentYear);
		return badmintonFixures;
	}
	
	@GET
	@Path("/getAllBadmintonFixures")
	@Produces(MediaType.APPLICATION_JSON)
	public List<BadmintonFixures> getAllBadmintonFixures()
	{
		List<BadmintonFixures> badmintonFixuresList = new ArrayList<BadmintonFixures> ();
		badmintonFixuresList = passDao.getAllBadmintonFixures();
		return badmintonFixuresList;
	}
	
	@GET
    @Produces(MediaType.APPLICATION_JSON)
	@Path("/getAllGames")
	public List<Games> getAllGames()
	{
		List<Games> gamesList = new ArrayList<Games> ();
		gamesList = passDao.getAllGames();
		return gamesList;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getBadmintonTournamentYears")
	public List<String> getBadmintonEventTournamentYears()
	{
		List<String> badmintonYearList = new ArrayList<String> ();
		badmintonYearList = passDao.getBadmintonEventTournamentYears();	
		return badmintonYearList;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getAllEntertainment")
	public List<Entertainment> getAllEntertainment()
	{
		List<Entertainment> entertainmentList = new ArrayList<Entertainment> ();
		entertainmentList = passDao.getAllEntertainments();	
		return entertainmentList;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getEntertainmentSource/{entertainmentCode}")
	@Consumes(MediaType.TEXT_PLAIN)
	public List<EntertainmentSource> getAllEntertainmentSource(@PathParam("entertainmentCode") String entertainmentCode)
	{
		List<EntertainmentSource> entertainmentSourceList = new ArrayList<EntertainmentSource> ();
		entertainmentSourceList = passDao.getAllEntertainmentSource(entertainmentCode);	
		return entertainmentSourceList;
	}
	
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getBadmintonResultsForTournamentYear/{tournamentYear}")
	@Consumes(MediaType.TEXT_PLAIN)
	public List<BadmintonEventResults> getBadmintonResultForTournamentYear(@PathParam("tournamentYear") String tournamentYear)
	{
		System.out.println("tournamenet Year:"+ tournamentYear);
		List<BadmintonEventResults> badmintonEventResultsList = new ArrayList<BadmintonEventResults> ();
		badmintonEventResultsList  = passDao.getBadmintonEventResults(tournamentYear);
		return badmintonEventResultsList;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getBadmintonFixuresForTournamentYear/{tournamentYear}")
	@Consumes(MediaType.TEXT_PLAIN)
	public List<BadmintonEventFixures> getBadmintonFixuresForTournamentYear(@PathParam("tournamentYear") String tournamentYear)
	{
		
		
		List<BadmintonEventFixures> badmintonEventFixuresList = new ArrayList<BadmintonEventFixures> ();
		badmintonEventFixuresList  = passDao.getBadmintonEventFixures(tournamentYear);
		return badmintonEventFixuresList;
	}
	
	@POST
	@Path("/insertgames")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage insertGames(Games games)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.insertGames(games);
		return outputMessage;
	}
	
	@POST
	@Path("/updategames")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage updateGames(Games games)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.updateGames(games);
		return outputMessage;
	}
	
	@POST
	@Path("/deletegames")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage deleteGames(Games games)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.deleteGames(games);
		return outputMessage;
	}
	
	@POST
	@Path("/updateentertainment")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage updateEntertainment(Entertainment entertainment)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.updateEntertainment(entertainment);
		return outputMessage;
	}
	
	@POST
	@Path("/insertentertainment")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage insertEntertainment(Entertainment entertainment)
	{	
		
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.insertEntertainment(entertainment);
		return outputMessage;
	}
	
	@POST
	@Path("/deleteentertainment")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage deleteEntertainment(Entertainment entertainment)
	{	
		
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.deleteEntertainment(entertainment);
		return outputMessage;
	}
	
	@POST
	@Path("/insertentertainmentsource")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage insertEntertainmentSource(EntertainmentSource entertainmentSource)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.insertEntertainmentSource(entertainmentSource);
		return outputMessage;
	}
	
	@POST
	@Path("/updateentertainmentsource")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage updateEntertainmentSource(EntertainmentSource entertainmentSource)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.updateEntertainmentSource(entertainmentSource);
		return outputMessage;
	}
	
	@POST
	@Path("/deleteentertainmentsource")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage deleteEntertainmentSource(EntertainmentSource entertainmentSource)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.deleteEntertainmentSource(entertainmentSource);
		return outputMessage;
	}
	
	@POST
	@Path("/updatebadmintonevents")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage updateBadmintonEvents(BadmintonEvents badmintonEvents)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.updateBadmintonEvents(badmintonEvents);
		return outputMessage;
	}
	
	@POST
	@Path("/insertbadmintonevents")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage insertBadmintonEvents(BadmintonEvents badmintonEvents)
	{	
		System.out.println("insert badminton event:"+ badmintonEvents.toString());
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.insertBadmintonEvents(badmintonEvents);
		return outputMessage;
	}
	
	@POST
	@Path("/insertbadmintonfixures")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage insertBadmintonFixures(BadmintonFixures badmintonFixures)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.insertBadmintonFixures(badmintonFixures);
		return outputMessage;
	}
	
	@POST
	@Path("/updatebadmintonfixures")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage updateBadmintonFixures(BadmintonFixures badmintonFixures)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.updateBadmintonFixures(badmintonFixures);
		return outputMessage;
	}
	
	@POST
	@Path("/deletebadmintonfixures")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage deleteBadmintonFixures(BadmintonFixures badmintonFixures)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.deleteBadmintonFixures(badmintonFixures);
		return outputMessage;
	}
	
	@POST
	@Path("/insertbadmintonresults")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage insertBadmintonResults(BadmintonResults badmintonResults)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.insertBadmintonResults(badmintonResults);
		return outputMessage;
	}
	@POST
	@Path("/updatebadmintonresults")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage updateBadmintonResults(BadmintonResults badmintonResults)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.updateBadmintonResults(badmintonResults);
		return outputMessage;
	}
	
	@POST
	@Path("/deletebadmintonresults")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage deleteBadmintonResults(BadmintonResults badmintonResults)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.deleteBadmintonResults(badmintonResults);
		return outputMessage;
	}
	
	@POST
	@Path("/deletebadmintonregistration")
	@Produces(MediaType.APPLICATION_JSON)
	@Consumes(MediaType.APPLICATION_JSON)
	public OutputMessage deleteBadmintonRegistration(RegisterBadminton registerBadminton)
	{	
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.deleteBadmintonRegistration(registerBadminton);
		return outputMessage;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getAllBadmintonEvents")
	public List<BadmintonEvents> getAllBadmintonEvents()
	{
		List<BadmintonEvents> badmintonEventList = new ArrayList<BadmintonEvents> ();
		badmintonEventList = passDao.getAllBadmintonEvents();	
		return badmintonEventList;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getAllBadmintonRegistration")
	public List<RegisterBadminton> getAllBadmintonRegistration()
	{
		List<RegisterBadminton> badmintonRegisterList = new ArrayList<RegisterBadminton> ();
		badmintonRegisterList = passDao.getAllBadmintonRegistration();	
		return badmintonRegisterList;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getDistinctBadmintonEvent")
	public List<DistinctBadmintonEvent> getDistinctBadmintonEvent()
	{
		List<DistinctBadmintonEvent> distinctBadmintonEventList = new ArrayList<DistinctBadmintonEvent>();
		distinctBadmintonEventList = passDao.getDistinctBadmintonEvent();	
		return distinctBadmintonEventList;
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/passwordreset")
	public OutputMessage passwordReset(PasswordReset passwordReset)
	{
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.passwordReset(passwordReset);
		return outputMessage;
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/insertuserinfo")
	public OutputMessage insertUserInfo(UserInfo userInfo)
	{
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.insertUserInfo(userInfo);
		return outputMessage;
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/updateuserinfo")
	public OutputMessage updateUserInfo(UserInfo userInfo)
	{
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.updateUserInfo(userInfo);
		return outputMessage;
	}
	
	@POST
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/deleteuserinfo")
	public OutputMessage deleteUserInfo(UserInfo userInfo)
	{
		OutputMessage outputMessage = new OutputMessage();
		outputMessage = passDao.deleteUserInfo(userInfo);
		return outputMessage;
	}
	
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	@Path("/getalluserinfo")
	public List<UserInfo> getAllUserInfo()
	{
		System.out.println("inside get user info");
		List<UserInfo> userInfo = new ArrayList<UserInfo> ();
		userInfo = passDao.getAllUserInfo();
		return userInfo;
	}
	

	@POST
	@Produces(MediaType.TEXT_PLAIN)
	@Path("/getbadmintonregistrationno")
	public String getBadmintonRegistrationNo()
	{
		String registrationNo;
		registrationNo = passDao.getBadmintonRegistrationNo();
		return registrationNo;
	}
	// This method is used for returning the current date
	public Date getCurrentDate()
	{
		Date currentDate = null;		
		try {
			DateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
			currentDate = new SimpleDateFormat("dd-MM-yyyy").parse(dateFormat.format(new Date()));
			
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return currentDate;
		
	}
	
	//This method is used for converting the util.date to sql.date
	public java.sql.Date convertToSqlDate(Date currentDate)
	{
		java.sql.Date sqlDate = new java.sql.Date(currentDate.getTime());
		return sqlDate;
	}
	


}
