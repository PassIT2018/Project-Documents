package com.pass.passdao;


import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import com.pass.model.BadmintonEventFixures;
import com.pass.model.BadmintonEventResults;
import com.pass.model.BadmintonEvents;
import com.pass.model.BadmintonFixures;
import com.pass.model.BadmintonResults;
import com.pass.model.ContactUs;
import com.pass.model.DistinctBadmintonEvent;
import com.pass.model.Entertainment;
import com.pass.model.EntertainmentSource;
import com.pass.model.Games;
import com.pass.model.OutputMessage;
import com.pass.model.PasswordReset;
import com.pass.model.RegisterBadminton;
import com.pass.model.UserInfo;

public class PassImpDao implements IPassDao {


	@Override
	public boolean insertContactUs(ContactUs contactUs) {
		
		boolean insertFlag = false;
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();
			String sql="insert into contact_us values(nextval('contact_us_seq'),?,?,?,?,?)";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			prepareStatement.setString(1, contactUs.getContactName());
			prepareStatement.setString(2, contactUs.getEmail());
			prepareStatement.setString(3, contactUs.getPhone());
			prepareStatement.setString(4, contactUs.getMessage());
			prepareStatement.setDate(5,(Date) contactUs.getDateInserted());
			int insrtCnt = prepareStatement.executeUpdate();
			
			if (insrtCnt > 0 )
			{
				insertFlag = true;
			}
			
			
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return insertFlag;
	}

	@Override
	public List<RegisterBadminton> getAllBadmintonRegistration() {
		List<RegisterBadminton> registerBadmintonList = new ArrayList<RegisterBadminton>();
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select tournament_year,registration_number,team_name,name,dob,"
					+ "email,phone,event_code,partner_name,partner_dob,payment_amount,game_code,"
					+ "date_inserted,date_updated,serial_number from badminton_registration order by registration_number";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				
				RegisterBadminton registerBadminton = new RegisterBadminton();
				registerBadminton.setTournamentYear(resultSet.getString(1));
				registerBadminton.setRegistrationNo(resultSet.getString(2));
				registerBadminton.setTeamName(resultSet.getString(3));
				registerBadminton.setName(resultSet.getString(4));
				registerBadminton.setDob(resultSet.getString(5));
				registerBadminton.setEmail(resultSet.getString(6));
				registerBadminton.setPhone(resultSet.getString(7));
				registerBadminton.setEventCode(resultSet.getString(8));
				registerBadminton.setPartnerName(resultSet.getString(9));
				registerBadminton.setPartnerDOB(resultSet.getString(10));
				registerBadminton.setPayementAmount(resultSet.getDouble(11));
				registerBadminton.setGameCode(resultSet.getString(12));
				registerBadminton.setDateInserted(resultSet.getString(13));
				registerBadminton.setDateUpdated(resultSet.getString(14));
				registerBadminton.setSerialNo(resultSet.getInt(15));
				
				registerBadmintonList.add(registerBadminton);
				
				
			}
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return registerBadmintonList;
	}
	
	@Override
	public OutputMessage registerBadminton(RegisterBadminton registerBadminton) {
		OutputMessage outputMessage = new OutputMessage();
		Connection con = null;
		InitialContext context;
		
		System.out.println("register:"+registerBadminton.toString());
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();
			
			String sql = "insert into badminton_registration values(?,?,?,?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			
			prepareStatement.setString(1,registerBadminton.getTournamentYear());
			prepareStatement.setString(2,this.getBadmintonRegistrationNo());
			prepareStatement.setString(3,registerBadminton.getTeamName());
			prepareStatement.setString(4,registerBadminton.getName());
			prepareStatement.setDate(5, this.convertToSqlDate(convertStringToDate(registerBadminton.getDob())));
			prepareStatement.setString(6,registerBadminton.getEmail());
			prepareStatement.setString(7,registerBadminton.getPhone());
			prepareStatement.setString(8,registerBadminton.getEventCode());
			prepareStatement.setString(9,registerBadminton.getPartnerName());
			if (registerBadminton.getPartnerDOB().isEmpty())
			{
				prepareStatement.setDate(10,null);
				
			}
			else
			{
				prepareStatement.setDate(10,this.convertToSqlDate(convertStringToDate(registerBadminton.getPartnerDOB())));
			}
			
			prepareStatement.setDouble(11,registerBadminton.getPayementAmount());
			prepareStatement.setString(12,registerBadminton.getGameCode());
			prepareStatement.setDate(13,this.convertToSqlDate(convertStringToDate(registerBadminton.getDateInserted())));
			
//			prepareStatement.setDate(14,this.convertToSqlDate(convertStringToDate(registerBadminton.getDateUpdated())));
			
			int insrtcnt = prepareStatement.executeUpdate();
			
			if(insrtcnt > 0)
			{
				outputMessage.setErrCode("0");
				outputMessage.setErrMsg("Successfull");
			}
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			outputMessage.setErrCode("1000");
			outputMessage.setErrMsg(e.getMessage());
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return outputMessage;
	}

	@Override
	public OutputMessage updateBadmintonRegistration(RegisterBadminton registerBadminton) {
		
		OutputMessage outputMessage = new OutputMessage();
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();
			
			String sql = "update badminton_registration set name = ? , dob = ? , email = ? , phone = ? , "
					+ "event_code = ? , partner_name = ?, partner_dob = ? ,date_updated = ? , payment_amount =  ? where "
					+ "registration_number = ? and serial_number = ?";
			
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			
			
			prepareStatement.setString(1,registerBadminton.getName());
			prepareStatement.setDate(2,this.convertToSqlDate(convertStringToDate(registerBadminton.getDob())));
			prepareStatement.setString(3,registerBadminton.getEmail());
			prepareStatement.setString(4,registerBadminton.getPhone());
			prepareStatement.setString(5,registerBadminton.getEventCode());
			prepareStatement.setString(6,registerBadminton.getPartnerName());
			prepareStatement.setDate(7,this.convertToSqlDate(convertStringToDate(registerBadminton.getPartnerDOB())));
			prepareStatement.setDate(8,this.convertToSqlDate(convertStringToDate(registerBadminton.getDateUpdated())));
			prepareStatement.setDouble(9,registerBadminton.getPayementAmount());
			prepareStatement.setString(10,registerBadminton.getRegistrationNo());
			prepareStatement.setInt(11,registerBadminton.getSerialNo());
			
			int updatecnt = prepareStatement.executeUpdate();
			
			if(updatecnt > 0)
			{
				outputMessage.setErrCode("0");
				outputMessage.setErrMsg("Successfull");
			}
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				outputMessage.setErrCode("1000");
				outputMessage.setErrMsg(e.getMessage());

			}
		}
		
		return outputMessage;
	}

	
	@Override
	public boolean validateTeamName(String teamName) {
		boolean validTeamFlag = false;
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select team_name from badminton_registration where team_name = ?";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			prepareStatement.setString(1,teamName);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			if(resultSet.next())
			{
				validTeamFlag = true;
			}
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return validTeamFlag;
	}

	@Override
	public RegisterBadminton getBadmintonRegistration(String registrationNo) {
		RegisterBadminton registerBadminton = new RegisterBadminton();
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select tournament_year,registration_number,team_name,name,dob,"
					+ "email,phone,event_code,partner_name,partner_dob,payment_amount,game_code,"
					+ "date_inserted,date_updated from badminton_registration where registration_number = ?";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			prepareStatement.setString(1,registrationNo);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				
				registerBadminton.setTournamentYear(resultSet.getString(1));
				registerBadminton.setRegistrationNo(resultSet.getString(2));
				registerBadminton.setTeamName(resultSet.getString(3));
				registerBadminton.setName(resultSet.getString(4));
				registerBadminton.setDob(resultSet.getString(5));
				registerBadminton.setEmail(resultSet.getString(6));
				registerBadminton.setPhone(resultSet.getString(7));
				registerBadminton.setEventCode(resultSet.getString(8));
				registerBadminton.setPartnerName(resultSet.getString(9));
				registerBadminton.setPartnerDOB(resultSet.getString(10));
				registerBadminton.setPayementAmount(resultSet.getDouble(11));
				registerBadminton.setGameCode(resultSet.getString(12));
				registerBadminton.setDateInserted(resultSet.getString(13));
				registerBadminton.setDateUpdated(resultSet.getString(14));
				
				
			}
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return registerBadminton;
	}

	@Override
	public List<BadmintonResults> getBadmintonResults(String tournamentYear) {
		
		List<BadmintonResults> badmintonResultList = new ArrayList<BadmintonResults>();
		
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select tournament_year,event_code,position,team_name,"
					+ "team_player1,team_player2,game_code from badminton_results where tournament_year =  ?"
					+ "order by serial_number asc";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			prepareStatement.setString(1,tournamentYear);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				BadmintonResults badmintonResults = new BadmintonResults();
				badmintonResults.setTournamentYear(resultSet.getString(1));
				badmintonResults.setEventCode(resultSet.getString(2));
				badmintonResults.setPosition(resultSet.getString(3));
				badmintonResults.setTeamName(resultSet.getString(4));
				badmintonResults.setPlayerName1(resultSet.getString(5));
				badmintonResults.setPlayerName2(resultSet.getString(6));
				badmintonResults.setGameCode(resultSet.getString(7));
				
				badmintonResultList.add(badmintonResults);
			}
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return badmintonResultList;
	}

	@Override
	public List<BadmintonResults> getAllBadmintonResults() {
		List<BadmintonResults> badmintonResultsList = new ArrayList<BadmintonResults>();
		
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select tournament_year,event_code,position,team_name,"
					+ "team_player1,team_player2,game_code,serial_number from badminton_results "
					+ "order by serial_number asc";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				BadmintonResults badmintonResults = new BadmintonResults();
				badmintonResults.setTournamentYear(resultSet.getString(1));
				badmintonResults.setEventCode(resultSet.getString(2));
				badmintonResults.setPosition(resultSet.getString(3));
				badmintonResults.setTeamName(resultSet.getString(4));
				badmintonResults.setPlayerName1(resultSet.getString(5));
				badmintonResults.setPlayerName2(resultSet.getString(6));
				badmintonResults.setGameCode(resultSet.getString(7));
				badmintonResults.setSerialNumber(resultSet.getInt(8));
				
				badmintonResultsList.add(badmintonResults);
			}
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return badmintonResultsList;
	}

	@Override
	public List<BadmintonFixures> getBadmintonFixures(String tournamentYear) {
		List<BadmintonFixures> badmintonFixuresList = new ArrayList<BadmintonFixures>();
		
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select tournament_year,event_code,match_number,team_name1,"
					+ "team_name2,match_date,match_time,court,winner from badminton_fixures where tournament_year =  ?"
					+ "order by tournament_year asc";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			prepareStatement.setString(1,tournamentYear);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				BadmintonFixures badmintonFixures = new BadmintonFixures();
				
				badmintonFixures.setTournamentYear(resultSet.getString(1));
				badmintonFixures.setEventCode(resultSet.getString(2));
				badmintonFixures.setMatchNumber(resultSet.getInt(3));
				badmintonFixures.setTeamName1(resultSet.getString(4));
				badmintonFixures.setTeamName2(resultSet.getString(5));
				badmintonFixures.setMatchDate(resultSet.getString(6));
				badmintonFixures.setMatchTime(resultSet.getString(7));
				badmintonFixures.setCourt(resultSet.getString(8));
				badmintonFixures.setWinner(resultSet.getString(9));
				
				badmintonFixuresList.add(badmintonFixures);
			}
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return badmintonFixuresList;
	}

	@Override
	public List<BadmintonFixures> getAllBadmintonFixures() {
		
		List<BadmintonFixures> badmintonFixuresList = new ArrayList<BadmintonFixures>();
		
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select tournament_year,event_code,match_number,team_name1,"
					+ "team_name2,match_date,match_time,court,winner,serial_number "
					+ " from badminton_fixures order by tournament_year asc";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				BadmintonFixures badmintonFixures = new BadmintonFixures();
				badmintonFixures.setTournamentYear(resultSet.getString(1));
				badmintonFixures.setEventCode(resultSet.getString(2));
				badmintonFixures.setMatchNumber(resultSet.getInt(3));
				badmintonFixures.setTeamName1(resultSet.getString(4));
				badmintonFixures.setTeamName2(resultSet.getString(5));
				badmintonFixures.setMatchDate(resultSet.getString(6));
				badmintonFixures.setMatchTime(resultSet.getString(7));
				badmintonFixures.setCourt(resultSet.getString(8));
				badmintonFixures.setWinner(resultSet.getString(9));
				badmintonFixures.setSerialNo(resultSet.getInt(10));
				
				badmintonFixuresList.add(badmintonFixures);
			}
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return badmintonFixuresList;
	}

	@Override
	public List<Games> getAllGames() {
		List<Games> gamesList = new ArrayList<Games>();
		
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();	
			
			String sql = "select game_code,game_name from games";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				Games games = new Games();
				games.setGameCode(resultSet.getString(1));
				games.setGameName(resultSet.getString(2));
				
				
				gamesList.add(games);
			}
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return gamesList;
	}

	

	@Override
	public List<String> getBadmintonEventTournamentYears() {
		List<String> badmintonYearList = new ArrayList<String>();
		
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select distinct(tournament_year) from badminton_events order by tournament_year desc";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
	
				
				badmintonYearList.add(resultSet.getString(1));
				
			}
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return badmintonYearList;
	}

	
	


@Override
public List<Entertainment> getAllEntertainments() {
	List<Entertainment> entertainmentList = new ArrayList<Entertainment>();
	
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "select entertainment_code,entertainment_name from entertainment";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		ResultSet resultSet = prepareStatement.executeQuery();
		
		while(resultSet.next())
		{
			Entertainment entertainment = new Entertainment();
			entertainment.setEntertainmentCode(resultSet.getString(1));
			entertainment.setEntertainmentName(resultSet.getString(2));
			
			
			entertainmentList.add(entertainment);
		}
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return entertainmentList;
}

@Override
public List<EntertainmentSource> getAllEntertainmentSource(String entertainmentCode) {
	List<EntertainmentSource> entertainmentSourceList = new ArrayList<EntertainmentSource>();
	
	Connection con = null;
	InitialContext context;
	PreparedStatement prepareStatement = null;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
	
		
		if (entertainmentCode.contentEquals("All"))
		{
			
			String sql = "select serial_number,entertainment_src_year,entertainment_code,entertainment_src_links,"
					+ "entertainment_display_order,  actor_name,critics_rating,user_rating,language,category,release_date,"
					+ " entertainment_name from entertainment_source "
					+ " order by serial_number,entertainment_src_year,entertainment_code,entertainment_display_order asc";
			prepareStatement = con.prepareStatement(sql);
				
		}
		else
		{
			String sql = "select serial_number,entertainment_src_year,entertainment_code,entertainment_src_links,"
					+ "entertainment_display_order,  actor_name,critics_rating,user_rating,language,category,release_date,"
					+ " entertainment_name from entertainment_source "
					+ " where entertainment_code = ? order by entertainment_display_order asc";
				prepareStatement = con.prepareStatement(sql);
				prepareStatement.setString(1,entertainmentCode);
		}
		
		
		
		ResultSet resultSet = prepareStatement.executeQuery();
		
		while(resultSet.next())
		{
			
			EntertainmentSource entertainmentSource = new EntertainmentSource();
			entertainmentSource.setSerialNumber(resultSet.getInt(1));
			entertainmentSource.setEntertainmentSrcYear(resultSet.getString(2));
			entertainmentSource.setEntertainmentCode(resultSet.getString(3));
			entertainmentSource.setEntertainmentSrcLink(resultSet.getString(4));
			entertainmentSource.setEntertainmentOrderDisplay(resultSet.getInt(5));		
			entertainmentSource.setActor_name(resultSet.getString(6));			
			entertainmentSource.setCritisRating(resultSet.getString(7));
			entertainmentSource.setUserRating(resultSet.getString(8));			
			entertainmentSource.setCategory(resultSet.getString(10));			
			entertainmentSource.setLanguage(resultSet.getString(9));			
			entertainmentSource.setReleaseDate(resultSet.getString(11));			
			entertainmentSource.setEntertainmentName(resultSet.getString(12));
			
			
			entertainmentSourceList.add(entertainmentSource);
		}
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	
	return entertainmentSourceList;
}
	

 



@Override
public List<BadmintonEventResults> getBadmintonEventResults(String tournamentYear) {
	List<BadmintonEventResults> badmintonEventResultList = new ArrayList<BadmintonEventResults>();
	
	List<String> badmintonEventNameList = new ArrayList<String>();
	badmintonEventNameList = this.getBadmintonEventNamesForTournamentYear(tournamentYear);
	

	
	boolean firstTime = true;
	boolean newList = true;
	Connection con = null;
	InitialContext context;
	
	
	for (String eventName : badmintonEventNameList)		
	{
		List<BadmintonResults> badmintonResultsList = new ArrayList<BadmintonResults> ();
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select b.tournament_year,b.event_code,b.position,b.team_name,"
					+ "b.team_player1,b.team_player2,b.game_code from badminton_results b , "
					+ " badminton_events a where a.event_code = b.event_code and "
					+ " a.tournament_year = b.tournament_year and  "
					+ " a.tournament_year = ? and"
					+ " a.event_name = ? ";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			prepareStatement.setString(1,tournamentYear);
			prepareStatement.setString(2,eventName);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				BadmintonResults badmintonResults = new BadmintonResults();
				badmintonResults.setTournamentYear(resultSet.getString(1));
				badmintonResults.setEventCode(resultSet.getString(2));
				badmintonResults.setPosition(resultSet.getString(3));
				badmintonResults.setTeamName(resultSet.getString(4));
				badmintonResults.setPlayerName1(resultSet.getString(5));
				badmintonResults.setPlayerName2(resultSet.getString(6));
				badmintonResults.setGameCode(resultSet.getString(7));
				
				badmintonResultsList.add(badmintonResults);
			}
			
			if (badmintonResultsList.isEmpty())
			{
				// Do nothing
			}
			else
			{
				badmintonEventResultList.add(new BadmintonEventResults(eventName,badmintonResultsList));
			}
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	return badmintonEventResultList;
}

@Override
public List<String> getBadmintonEventNamesForTournamentYear(String tournamentYear) {
	List<String> badmintonEventNameList = new ArrayList<String>();
	
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();			
		String sql = "select event_name from badminton_events where tournament_year = ? order by event_code asc";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(1,tournamentYear);
		ResultSet resultSet = prepareStatement.executeQuery();
		
		while(resultSet.next())
		{
			
			badmintonEventNameList.add(resultSet.getString(1));
		
			
		}
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return badmintonEventNameList;
}

@Override
public List<BadmintonEventFixures> getBadmintonEventFixures(String tournamentYear) {
List<BadmintonEventFixures> badmintonEventFixuresList = new ArrayList<BadmintonEventFixures>();
	
	List<String> badmintonEventNameList = new ArrayList<String>();
	badmintonEventNameList = this.getBadmintonEventNamesForTournamentYear(tournamentYear);
	
	Connection con = null;
	InitialContext context;
	
	
	for (String eventName : badmintonEventNameList)		
	{
		List<BadmintonFixures> badmintonFixuresList = new ArrayList<BadmintonFixures> ();
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();			
			String sql = "select a.tournament_year,a.event_code,a.match_number,a.team_name1,"
					+ "a.team_name2,a.match_date,a.match_time,a.court,a.winner "
					+ " from badminton_fixures a, badminton_events b "
					+ "where a.tournament_year = b.tournament_year "
					+ "and a.event_code = b.event_code "
					+ "and a.tournament_year = ? and "
					+ "b.event_name =  ? ";
			
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			prepareStatement.setString(1,tournamentYear);
			prepareStatement.setString(2,eventName);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				BadmintonFixures badmintonFixures = new BadmintonFixures();
				badmintonFixures.setTournamentYear(resultSet.getString(1));
				badmintonFixures.setEventCode(resultSet.getString(2));
				badmintonFixures.setMatchNumber(resultSet.getInt(3));
				badmintonFixures.setTeamName1(resultSet.getString(4));
				badmintonFixures.setTeamName2(resultSet.getString(5));
				badmintonFixures.setMatchDate(resultSet.getString(6));
				badmintonFixures.setMatchTime(resultSet.getString(7));
				badmintonFixures.setCourt(resultSet.getString(8));
				badmintonFixures.setWinner(resultSet.getString(9));
				
				badmintonFixuresList.add(badmintonFixures);
			}
			
			if (badmintonFixuresList.isEmpty())
			{
				//Do nothing
			}
			else
			{
				badmintonEventFixuresList.add(new BadmintonEventFixures(eventName,badmintonFixuresList));
			}
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
	
	
	return badmintonEventFixuresList;
}

@Override
public OutputMessage insertGames(Games games) {
	
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "insert into games values(?,?)";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(1,games.getGameCode());
		prepareStatement.setString(2,games.getGameName());
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage updateGames(Games games) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "update games set game_name = ? where game_code = ? ";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(1,games.getGameName());
		prepareStatement.setString(2,games.getGameCode());
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage deleteGames(Games games) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "delete from games where game_code = ? ";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(1,games.getGameCode());
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage insertEntertainment(Entertainment entertainment) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "insert into entertainment values(?,?)";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(2,entertainment.getEntertainmentCode());
		prepareStatement.setString(1,entertainment.getEntertainmentName());
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage updateEntertainment(Entertainment entertainment) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "update entertainment set entertainment_name = ? where entertainment_code = ? ";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(1,entertainment.getEntertainmentName());
		prepareStatement.setString(2,entertainment.getEntertainmentCode());
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage deleteEntertainment(Entertainment entertainment) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "delete from entertainment  where entertainment_code = ? ";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(1,entertainment.getEntertainmentCode());
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage insertEntertainmentSource(EntertainmentSource entertainmentSource) {

	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "insert into entertainment_source values(?,?,?,?,?,?,?,?,?,?,?,?)";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setInt(1,entertainmentSource.getSerialNumber());
		prepareStatement.setString(2,entertainmentSource.getEntertainmentSrcYear());
		prepareStatement.setString(3,entertainmentSource.getEntertainmentCode());
		prepareStatement.setString(4,entertainmentSource.getEntertainmentSrcLink());
		prepareStatement.setInt(5,entertainmentSource.getEntertainmentOrderDisplay());
		prepareStatement.setString(6,entertainmentSource.getActorName());
		prepareStatement.setString(7,entertainmentSource.getCritisRating());
		prepareStatement.setString(8,entertainmentSource.getUserRating());
		prepareStatement.setString(9,entertainmentSource.getLanguage());
		prepareStatement.setString(10,entertainmentSource.getCategory());
		prepareStatement.setString(11,entertainmentSource.getReleaseDate());
		prepareStatement.setString(12,entertainmentSource.getEntertainmentName());
		
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage deleteEntertainmentSource(EntertainmentSource entertainmentSource) {

	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "Delete from entertainment_source  where serial_number = ? and entertainment_src_year = ?";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setInt(1,entertainmentSource.getSerialNumber());
		prepareStatement.setString(2,entertainmentSource.getEntertainmentSrcYear());
		
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage updateEntertainmentSource(EntertainmentSource entertainmentSource) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	System.out.println("entertainment so:"+entertainmentSource.toString());
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "update entertainment_source set entertainment_src_year = ?,"
				+ "entertainment_code = ?,"
				+ "entertainment_src_links = ? ,"
				+ "entertainment_display_order = ?,"
				+ "actor_name = ? ,"
				+ "critics_rating = ?,"
				+ "user_rating = ?,"
				+ "language = ?,"
				+ "category = ?,"
				+ "release_date = ?,"
				+ "entertainment_name = ? where serial_number = ?";
		
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setInt(12,entertainmentSource.getSerialNumber());
		prepareStatement.setString(1,entertainmentSource.getEntertainmentSrcYear());
		prepareStatement.setString(2,entertainmentSource.getEntertainmentCode());
		prepareStatement.setString(3,entertainmentSource.getEntertainmentSrcLink());
		prepareStatement.setInt(4,entertainmentSource.getEntertainmentOrderDisplay());
		prepareStatement.setString(5,entertainmentSource.getActorName());
		prepareStatement.setString(6,entertainmentSource.getCritisRating());
		prepareStatement.setString(7,entertainmentSource.getUserRating());
		prepareStatement.setString(8,entertainmentSource.getLanguage());
		prepareStatement.setString(9,entertainmentSource.getCategory());
		prepareStatement.setString(10,entertainmentSource.getReleaseDate());
		prepareStatement.setString(11,entertainmentSource.getEntertainmentName());
		
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage insertBadmintonEvents(BadmintonEvents badmintonEvents) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "insert into badminton_events values(?,?,?,?,?)";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(1,badmintonEvents.getTournamentYear());
		prepareStatement.setString(2,badmintonEvents.getEventCode());
		prepareStatement.setString(3,badmintonEvents.getEventName());
		prepareStatement.setString(4,badmintonEvents.getGameCode());
		prepareStatement.setDouble(5,badmintonEvents.getAmount());
		
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage updateBadmintonEvents(BadmintonEvents badmintonEvents) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "update badminton_events set event_name =?,"
				+ "game_code = ?,"
				+ "amount = ?  where tournament_year = ? and event_code = ?";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(4,badmintonEvents.getTournamentYear());
		prepareStatement.setString(5,badmintonEvents.getEventCode());
		prepareStatement.setString(1,badmintonEvents.getEventName());
		prepareStatement.setString(2,badmintonEvents.getGameCode());
		prepareStatement.setDouble(3,badmintonEvents.getAmount());
		
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage insertBadmintonFixures(BadmintonFixures badmintonFixures) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "insert into badminton_fixures values(?,?,?,?,?,?,?,?,?)";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(1,badmintonFixures.getTournamentYear());
		prepareStatement.setString(2,badmintonFixures.getEventCode());
		prepareStatement.setInt(3,badmintonFixures.getMatchNumber());
		prepareStatement.setString(4,badmintonFixures.getTeamName1());
		prepareStatement.setString(5,badmintonFixures.getTeamName2());
		prepareStatement.setDate(6,this.convertToSqlDate(this.convertStringToDate(badmintonFixures.getMatchDate())));
		prepareStatement.setString(7,badmintonFixures.getMatchTime());
		prepareStatement.setString(8,badmintonFixures.getCourt());
		prepareStatement.setString(9,badmintonFixures.getWinner());
		
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage updateBadmintonFixures(BadmintonFixures badmintonFixures) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "update badminton_fixures set team_name1 = ?,"
				+ "team_name2 = ?,"
				+ "match_date = ?,"
				+ "match_time = ?,"
				+ "court = ?,"
				+ "winner = ? where tournament_year = ? and event_code = ? and match_number = ? and serial_number = ?";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(7,badmintonFixures.getTournamentYear());
		prepareStatement.setString(8,badmintonFixures.getEventCode());
		prepareStatement.setInt(9,badmintonFixures.getMatchNumber());
		prepareStatement.setInt(10,badmintonFixures.getSerialNo());
		prepareStatement.setString(1,badmintonFixures.getTeamName1());
		prepareStatement.setString(2,badmintonFixures.getTeamName2());
		prepareStatement.setDate(3,this.convertToSqlDate(this.convertStringToDate(badmintonFixures.getMatchDate())));
		prepareStatement.setString(4,badmintonFixures.getMatchTime());
		prepareStatement.setString(5,badmintonFixures.getCourt());
		prepareStatement.setString(6,badmintonFixures.getWinner());
		
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage deleteBadmintonFixures(BadmintonFixures badmintonFixures) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "Delete from badminton_fixures where tournament_year = ? and event_code = ? and match_number = ? and serial_number = ?";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(1,badmintonFixures.getTournamentYear());
		prepareStatement.setString(2,badmintonFixures.getEventCode());
		prepareStatement.setInt(3,badmintonFixures.getMatchNumber());
		prepareStatement.setInt(4,badmintonFixures.getSerialNo());
		
		
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage insertBadmintonResults(BadmintonResults badmintonResults) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "insert into badminton_results values(?,?,?,?,?,?,?)";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(1,badmintonResults.getTournamentYear());
		prepareStatement.setString(2,badmintonResults.getEventCode());
		prepareStatement.setString(3,badmintonResults.getPosition());
		prepareStatement.setString(4,badmintonResults.getTeamName());
		prepareStatement.setString(5,badmintonResults.getPlayerName1());
		prepareStatement.setString(6,badmintonResults.getPlayerName2());
		prepareStatement.setString(7,badmintonResults.getGameCode());
		
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage updateBadmintonResults(BadmintonResults badmintonResults) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "update badminton_results set tournament_year = ?, event_code= ?, position = ?,"
				+ "team_name = ?,"
				+ "team_player1 = ?,"
				+ "team_player2 = ?,"
				+ "game_code = ?"
				+ "where serial_number = ? ";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		prepareStatement.setString(1,badmintonResults.getTournamentYear());
		prepareStatement.setString(2,badmintonResults.getEventCode());
		prepareStatement.setString(3,badmintonResults.getPosition());
		prepareStatement.setString(4,badmintonResults.getTeamName());
		prepareStatement.setString(5,badmintonResults.getPlayerName1());
		prepareStatement.setString(6,badmintonResults.getPlayerName2());
		prepareStatement.setString(7,badmintonResults.getGameCode());
		prepareStatement.setInt(8,badmintonResults.getSerialNumber());
		
		
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage deleteBadmintonResults(BadmintonResults badmintonResults) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "Delete from badminton_results where tournament_year = ? and event_code = ? and serial_number = ?" ;
				
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		
		prepareStatement.setString(1,badmintonResults.getTournamentYear());
		prepareStatement.setString(2,badmintonResults.getEventCode());
		prepareStatement.setInt(3,badmintonResults.getSerialNumber());
		
		
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public OutputMessage deleteBadmintonRegistration(RegisterBadminton badmintonRegistration) {
	OutputMessage outputMessage = new OutputMessage();
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "Delete from badminton_registration " 
				+ "where registration_number = ? ";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		
		prepareStatement.setString(1,badmintonRegistration.getRegistrationNo());
		
		
		
		int insrtCnt = prepareStatement.executeUpdate();
		
		if(insrtCnt > 0)
		{
			outputMessage.setErrCode("0");
			outputMessage.setErrMsg("Successfull");
		}
		
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
		outputMessage.setErrCode("1000");
		outputMessage.setErrMsg(e.getMessage());
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return outputMessage;
}

@Override
public List<BadmintonEvents> getAllBadmintonEvents() {
List<BadmintonEvents> badmintonEventList = new ArrayList<BadmintonEvents>();
	
	Connection con = null;
	InitialContext context;
	
	try {
		context = new InitialContext();
		DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
		con = dataSource.getConnection();	
		
		String sql = "select tournament_year,event_code,event_name,game_code,amount from badminton_events";
		PreparedStatement prepareStatement = con.prepareStatement(sql);
		ResultSet resultSet = prepareStatement.executeQuery();
		
		while(resultSet.next())
		{
			BadmintonEvents badmintonEvents = new BadmintonEvents();
			badmintonEvents.setTournamentYear(resultSet.getString(1));
			badmintonEvents.setEventCode(resultSet.getString(2));
			badmintonEvents.setEventName(resultSet.getString(3));
			badmintonEvents.setGameCode(resultSet.getString(4));
			badmintonEvents.setAmount(resultSet.getDouble(5));
			
			badmintonEventList.add(badmintonEvents);
		}
		
		
		
	} catch (NamingException | SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	finally
	{
		try {
			con.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	return badmintonEventList;
}
 

public java.util.Date convertStringToDate(String dateString)

{
	 java.util.Date date = null;
	 SimpleDateFormat simpleDate = new SimpleDateFormat("dd-MM-yyyy");
	 try {
		 date = simpleDate.parse(dateString);
	} catch (ParseException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return date;
	 
}


	@Override
	public List<DistinctBadmintonEvent> getDistinctBadmintonEvent() {
		Connection con = null;
		InitialContext context;
		List<DistinctBadmintonEvent> distinctBadmintonEventList = new ArrayList<DistinctBadmintonEvent>();
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();	
			
			String sql = "select distinct event_code,event_name from badminton_events";
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			ResultSet resultSet = prepareStatement.executeQuery();
			
			while(resultSet.next())
			{
				DistinctBadmintonEvent distinctBadmintonEvents = new DistinctBadmintonEvent();
				
				distinctBadmintonEvents.setEventCode(resultSet.getString(1));
				distinctBadmintonEvents.setEventName(resultSet.getString(2));
				
				
				distinctBadmintonEventList.add(distinctBadmintonEvents);
			}
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return distinctBadmintonEventList;
	}

	@Override
	public OutputMessage passwordReset(PasswordReset passwordReset) {
		OutputMessage outputMessage = new OutputMessage();
		Connection con = null;
		InitialContext context;
		
		try {
			context = new InitialContext();
			DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
			con = dataSource.getConnection();	
			
			String sql = "update user_info set password = ? where email = ? " ;
					
			PreparedStatement prepareStatement = con.prepareStatement(sql);
			
			prepareStatement.setString(1,passwordReset.getPassword());
			prepareStatement.setString(2,passwordReset.getUserName());
			
			int insrtCnt = prepareStatement.executeUpdate();
			System.out.println("insrtCnt:"+insrtCnt);
			if(insrtCnt > 0)
			{
				outputMessage.setErrCode("0");
				outputMessage.setErrMsg("Successfull");
			}
			else
			{
				outputMessage.setErrCode("1000");
				outputMessage.setErrMsg("User name not found. Please try again with correct user name.");
			}
			
			
			
			
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			outputMessage.setErrCode("1000");
			outputMessage.setErrMsg(e.getMessage());
		}
		finally
		{
			try {
				con.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return outputMessage;
	}
	
	public static  java.util.Date convertSqlDateToUtilDate(java.sql.Date sqlDate)
	{
		java.util.Date utilDate = null;
		if (sqlDate != null)
		{
			
			utilDate = new java.util.Date(sqlDate.getTime());
			
		}
		
		return utilDate;
		
	}


	//This method is used for converting the util.date to sql.date
		public java.sql.Date convertToSqlDate(java.util.Date date)
		{
			java.sql.Date sqlDate = new java.sql.Date(date.getTime());
			return sqlDate;
		}

		@Override
		public OutputMessage insertUserInfo(UserInfo userInfo) {
			OutputMessage outputMessage = new OutputMessage();
			Connection con = null;
			InitialContext context;
			
			try {
				context = new InitialContext();
				DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
				con = dataSource.getConnection();	
				
				String sql = "insert into user_info values(?,?,?,?,?,?,?,?)" ;
						
				PreparedStatement prepareStatement = con.prepareStatement(sql);
				
				prepareStatement.setInt(1,userInfo.getSerialNumber());
				prepareStatement.setString(2,userInfo.getFirstName());
				prepareStatement.setString(3,userInfo.getLastName());
				prepareStatement.setString(4,userInfo.getAddress());
				prepareStatement.setString(5,userInfo.getEmail());
				prepareStatement.setString(6,userInfo.getPassword());
				prepareStatement.setString(7,userInfo.getRoles());
				
				if (userInfo.getStatus() == "Active")
				{
					prepareStatement.setBoolean(8,Boolean.TRUE);
				}
				else
				{
					prepareStatement.setBoolean(8,Boolean.FALSE);
				}
				
				
				
				int insrtCnt = prepareStatement.executeUpdate();
				
				if(insrtCnt > 0)
				{
					outputMessage.setErrCode("0");
					outputMessage.setErrMsg("Successfull");
				}
				
				
				
				
			} catch (NamingException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				outputMessage.setErrCode("1000");
				outputMessage.setErrMsg(e.getMessage());
			}
			finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return outputMessage;
		}

		@Override
		public OutputMessage updateUserInfo(UserInfo userInfo) {
			OutputMessage outputMessage = new OutputMessage();
			Connection con = null;
			InitialContext context;
			
			try {
				context = new InitialContext();
				DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
				con = dataSource.getConnection();	
				
				String sql = "update user_info set first_name = ? , last_name = ?, address = ?,"
						+ "email = ?, roles = ?, status = ? where email = ?  and serial_number = ?" ;
						
				PreparedStatement prepareStatement = con.prepareStatement(sql);
				
				System.out.println("userinfo:"+userInfo.toString());
				
				prepareStatement.setString(1,userInfo.getFirstName());
				prepareStatement.setString(2,userInfo.getLastName());
				prepareStatement.setString(3,userInfo.getAddress());
				prepareStatement.setString(4,userInfo.getEmail());
				prepareStatement.setString(5,userInfo.getRoles());
				if (userInfo.getStatus().contains("Active"))
				{
					prepareStatement.setBoolean(6,Boolean.TRUE);
				}
				else
				{
					prepareStatement.setBoolean(6,Boolean.FALSE);
				}
				
				prepareStatement.setString(7,userInfo.getEmail());
				prepareStatement.setInt(8,userInfo.getSerialNumber());
				
				int insrtCnt = prepareStatement.executeUpdate();
				
				if(insrtCnt > 0)
				{
					outputMessage.setErrCode("0");
					outputMessage.setErrMsg("Successfull");
				}
				else
				{
					outputMessage.setErrCode("1000");
					outputMessage.setErrMsg("Data is not updated successfully.");
				}
				
				
				
				
			} catch (NamingException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				outputMessage.setErrCode("1000");
				outputMessage.setErrMsg(e.getMessage());
			}
			finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return outputMessage;
		}

		@Override
		public OutputMessage deleteUserInfo(UserInfo userInfo) {
			OutputMessage outputMessage = new OutputMessage();
			Connection con = null;
			InitialContext context;
			
			try {
				context = new InitialContext();
				DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
				con = dataSource.getConnection();	
				
				String sql = "delete from  user_info  where email = ?  and serial_number = ?" ;
						
				PreparedStatement prepareStatement = con.prepareStatement(sql);
				
				
				prepareStatement.setString(1,userInfo.getEmail());
				prepareStatement.setInt(2,userInfo.getSerialNumber());
				
				int insrtCnt = prepareStatement.executeUpdate();
				
				if(insrtCnt > 0)
				{
					outputMessage.setErrCode("0");
					outputMessage.setErrMsg("Successfull");
				}
				else
				{
					outputMessage.setErrCode("1000");
					outputMessage.setErrMsg("Data is not found");
				}
				
				
				
				
			} catch (NamingException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				outputMessage.setErrCode("1000");
				outputMessage.setErrMsg(e.getMessage());
			}
			finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return outputMessage;
		}

		@Override
		public List<UserInfo> getAllUserInfo() {
			List<UserInfo> userInfoList = new ArrayList<UserInfo>();
			
			Connection con = null;
			InitialContext context;
			
			try {
				context = new InitialContext();
				DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
				con = dataSource.getConnection();	
				
				String sql = "select serial_number,first_name,last_name,address,email,password,roles,status from user_info order by serial_number";
				PreparedStatement prepareStatement = con.prepareStatement(sql);
				ResultSet resultSet = prepareStatement.executeQuery();
				
				while(resultSet.next())
				{
					UserInfo userInfo = new UserInfo();
					userInfo.setSerialNumber(resultSet.getInt(1));
					userInfo.setFirstName(resultSet.getString(2));
					userInfo.setLastName(resultSet.getString(3));
					userInfo.setAddress(resultSet.getString(4));
					userInfo.setEmail(resultSet.getString(5));
					userInfo.setPassword(resultSet.getString(6));
					userInfo.setRoles(resultSet.getString(7));
					
					if (resultSet.getBoolean(8) == true)
					{
						userInfo.setStatus("Active");
					}
					else
					{
						userInfo.setStatus("In Active");
					}
					
					
					userInfoList.add(userInfo);
				}
				
				
				
			} catch (NamingException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return userInfoList;
		}

		@Override
		public String getBadmintonRegistrationNo() {
			Connection con = null;
			boolean result = false;
			InitialContext context;
			int sequence = 0;
			int year = 0 ;
			String registrationNo = null;
			
			
			try {
				context = new InitialContext();
				DataSource dataSource = (DataSource) context.lookup("java:comp/env/jdbc/db");
				con = dataSource.getConnection();	
				
				String sql = "select registration_number from badminton_registration where serial_number  in "
						+ "(select max(serial_number) from badminton_registration)";
				PreparedStatement prepareStatement = con.prepareStatement(sql);
				ResultSet resultSet = prepareStatement.executeQuery();

				result = resultSet.next();
				
				if(result == false)
				{
					year = Calendar.getInstance().get(Calendar.YEAR);
					registrationNo = year + "0001";
				}
				else
				{
						while(resultSet.next())
						{
							
							year = Calendar.getInstance().get(Calendar.YEAR);
			
								if (year ==  Integer.parseInt(resultSet.getString(1).substring(0,4)))
								{
									sequence = Integer.parseInt(resultSet.getString(1));
									registrationNo = Integer.toString(sequence + 1);
									
								}		
								else
								{
									registrationNo = year + "0001";
								}
						}	
				}
				
				
				
				
				
			} catch (NamingException | SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally
			{
				try {
					con.close();
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return registrationNo;
		}

		



		
		
}
