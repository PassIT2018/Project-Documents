package com.pass.passdao;


import java.util.List;

import com.pass.model.BadmintonEventFixures;
import com.pass.model.BadmintonEventResults;
import com.pass.model.BadmintonEvents;
import com.pass.model.BadmintonFixures;
import com.pass.model.BadmintonResults;
import com.pass.model.ContactUs;
import com.pass.model.DistinctBadmintonEvent;
import com.pass.model.Entertainment;
import com.pass.model.EntertainmentSource;
import com.pass.model.Games;
import com.pass.model.OutputMessage;
import com.pass.model.PasswordReset;
import com.pass.model.RegisterBadminton;
import com.pass.model.UserInfo;

public interface IPassDao {
	
	
	public boolean insertContactUs(ContactUs contactUs);
	public OutputMessage registerBadminton(RegisterBadminton registerBadminton);
	public RegisterBadminton getBadmintonRegistration(String registationNo);
	public OutputMessage updateBadmintonRegistration(RegisterBadminton registerBadminton);
	public boolean validateTeamName(String teamName);
	public List<BadmintonResults> getBadmintonResults(String tournamentYear);
	public List<BadmintonResults> getAllBadmintonResults();
	public List<BadmintonFixures> getBadmintonFixures(String tournamentYear);
	public List<BadmintonFixures> getAllBadmintonFixures();
	public List<Games> getAllGames();
	public List<String> getBadmintonEventTournamentYears();
	public List<String> getBadmintonEventNamesForTournamentYear(String tournamentYear);
	public List<Entertainment> getAllEntertainments();
	public List<EntertainmentSource> getAllEntertainmentSource(String entertainmentCode);
	public List<BadmintonEventResults> getBadmintonEventResults(String tournamentYear);
	public List<BadmintonEventFixures> getBadmintonEventFixures(String tournamentYear);
	public List<BadmintonEvents> getAllBadmintonEvents();
	public List<DistinctBadmintonEvent> getDistinctBadmintonEvent();
	
	
	public OutputMessage insertGames(Games games);
	public OutputMessage updateGames(Games games);
	public OutputMessage deleteGames(Games games);
	
	
	public OutputMessage insertEntertainment(Entertainment entertainment);
	public OutputMessage updateEntertainment(Entertainment entertainment);
	public OutputMessage deleteEntertainment(Entertainment entertainment);
	
	public OutputMessage insertEntertainmentSource(EntertainmentSource entertainmentSource);
	public OutputMessage updateEntertainmentSource(EntertainmentSource entertainmentSource);
	public OutputMessage deleteEntertainmentSource(EntertainmentSource entertainmentSource);
	
	public OutputMessage insertBadmintonEvents(BadmintonEvents badmintonEvents);
	public OutputMessage updateBadmintonEvents(BadmintonEvents badmintonEvents);
	
	public OutputMessage insertBadmintonFixures(BadmintonFixures badmintonFixures);
	public OutputMessage updateBadmintonFixures(BadmintonFixures badmintonFixures);
	public OutputMessage deleteBadmintonFixures(BadmintonFixures badmintonFixures);
	
	
	public OutputMessage insertBadmintonResults(BadmintonResults badmintonResults);
	public OutputMessage updateBadmintonResults(BadmintonResults badmintonResults);
	public OutputMessage deleteBadmintonResults(BadmintonResults badmintonResults);
	
	
	public List<RegisterBadminton> getAllBadmintonRegistration();
	public OutputMessage deleteBadmintonRegistration(RegisterBadminton badmintonRegistration);
	
	public OutputMessage insertUserInfo(UserInfo userInfo);
	public OutputMessage updateUserInfo(UserInfo userInfo);
	public OutputMessage deleteUserInfo(UserInfo userInfo);
	public List<UserInfo>  getAllUserInfo();
	public OutputMessage passwordReset(PasswordReset passwordReset);
	public String getBadmintonRegistrationNo();
	
	
	
	
	
	
	

}
