package com.pass.model;

import java.io.Serializable;
import java.util.List;

public class BadmintonEventFixures implements Serializable {
	
	private String eventName;
	private List<BadmintonFixures> badmintonFixuresList;
	
	public BadmintonEventFixures()
	{
		this.eventName = "";
		this.badmintonFixuresList = null;
	}
	public BadmintonEventFixures(String eventName, List<BadmintonFixures> badmintonFixuresList) {
		super();
		this.eventName = eventName;
		this.badmintonFixuresList = badmintonFixuresList;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public List<BadmintonFixures> getBadmintonFixuresList() {
		return badmintonFixuresList;
	}
	public void setBadmintonFixuresList(List<BadmintonFixures> badmintonFixuresList) {
		this.badmintonFixuresList = badmintonFixuresList;
	}
	@Override
	public String toString() {
		return "BadmintonEventFixures [eventName=" + eventName + ", badmintonFixureList=" + badmintonFixuresList + "]";
	}
	
	


}
