package com.pass.model;

import java.io.Serializable;
import java.util.List;

public class BadmintonEventResults implements Serializable {
	
	private String eventName;
	private List<BadmintonResults> badmintonResultList;
	
	public BadmintonEventResults()
	{
		this.eventName = "";
		this.badmintonResultList = null;
	}
	public BadmintonEventResults(String eventName, List<BadmintonResults> badmintonResultList) {
		super();
		this.eventName = eventName;
		this.badmintonResultList = badmintonResultList;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public List<BadmintonResults> getBadmintonResultList() {
		return badmintonResultList;
	}
	public void setBadmintonResultList(List<BadmintonResults> badmintonResultList) {
		this.badmintonResultList = badmintonResultList;
	}
	@Override
	public String toString() {
		return "BadmintonEventResults [eventName=" + eventName + ", badmintonResultList=" + badmintonResultList + "]";
	}
	
	

}
