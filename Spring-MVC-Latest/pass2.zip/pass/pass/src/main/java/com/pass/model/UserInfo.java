package com.pass.model;

import java.io.Serializable;

public class UserInfo implements Serializable {
	
	private int serialNumber ;
	private String firstName;
	private String lastName;
	private String address;
	private String email;
	private String password;
	private String roles;
	private String status;
	
	
	public UserInfo()
	{
		this.serialNumber = 0;
		this.firstName = "";
		this.lastName = "";
		this.address = "";
		this.email = "";
		this.password = "";
		this.roles = "";
		this.status = "";
	}
	public UserInfo(int serialNumber, String firstName, String lastName, String address, String email, String password,
			String roles, String status) {
		super();
		this.serialNumber = serialNumber;
		this.firstName = firstName;
		this.lastName = lastName;
		this.address = address;
		this.email = email;
		this.password = password;
		this.roles = roles;
		this.status = status;
	}
	public int getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getRoles() {
		return roles;
	}
	public void setRoles(String roles) {
		this.roles = roles;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	@Override
	public String toString() {
		return "UserInfo [serialNumber=" + serialNumber + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", address=" + address + ", email=" + email + ", password=" + password + ", roles=" + roles
				+ ", status=" + status + "]";
	}
	
	

}
