package com.pass.restservice;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.ws.rs.core.MediaType;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pass.model.BadmintonEventFixures;
import com.pass.model.BadmintonEventResults;
import com.pass.model.BadmintonEvents;
import com.pass.model.BadmintonFixures;
import com.pass.model.BadmintonResults;
import com.pass.model.DistinctBadmintonEvent;
import com.pass.model.Entertainment;
import com.pass.model.EntertainmentSource;
import com.pass.model.Games;
import com.pass.model.RegisterBadminton;
import com.pass.model.UserInfo;
import com.sun.istack.logging.Logger;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.WebResource;

public class RestWebService {
	
	
	public List<String> getTournamentYear() throws JsonParseException, JsonMappingException, IOException
	{
		List<String> tournamentYears = new ArrayList<String>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getBadmintonTournamentYears";
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
		
		ObjectMapper mapper = new ObjectMapper();
		tournamentYears = mapper.readValue(webServiceData, new TypeReference<List<String>>() {});

		return tournamentYears;
		
	}
	
	
	
	
	public List<Games> getAllGames() throws JsonParseException, JsonMappingException, IOException
	{
		List<Games> gamesList = new ArrayList<Games>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getAllGames";
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
		
		ObjectMapper mapper = new ObjectMapper();
		gamesList = mapper.readValue(webServiceData, new TypeReference<List<Games>>() {});
		
		return gamesList;
		
	}
	
	public List<BadmintonResults> getBadmintonResultForTournamentYear(String tournamentYear) throws JsonParseException, JsonMappingException, IOException
	{
		List<BadmintonResults> badmintonResultsList = new ArrayList<BadmintonResults>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getBadmintonResults/"+tournamentYear;
		System.out.println("url:"+url);
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
	
		
		ObjectMapper mapper = new ObjectMapper();
		badmintonResultsList = mapper.readValue(webServiceData, new TypeReference<List<BadmintonResults>>() {});
			

		return badmintonResultsList;
		
	}
	
	public List<BadmintonFixures> getBadmintonFixuresForTournamentYear(String tournamentYear) throws JsonParseException, JsonMappingException, IOException
	{
		List<BadmintonFixures> badmintonFixuresList = new ArrayList<BadmintonFixures>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getBadmintonFixures/"+tournamentYear;
		System.out.println("url:"+url);
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
	
		
		ObjectMapper mapper = new ObjectMapper();
		badmintonFixuresList = mapper.readValue(webServiceData, new TypeReference<List<BadmintonFixures>>() {});
	
		
		return badmintonFixuresList;
		
	}
	
	
	public List<EntertainmentSource> getAllEntertainmentSource(String entertainmentCode) throws JsonParseException, JsonMappingException, IOException
	{
		List<EntertainmentSource> entertainmentSourceList = new ArrayList<EntertainmentSource>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getEntertainmentSource/"+ entertainmentCode;
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
		
		ObjectMapper mapper = new ObjectMapper();		
		entertainmentSourceList = mapper.readValue(webServiceData, new TypeReference<List<EntertainmentSource>>() {});		
		
		for(EntertainmentSource entertainSrc : entertainmentSourceList)
		{
			if (entertainSrc.getActorName().isEmpty())
			{
				entertainSrc.setActorName("No Data");
			}
			if (entertainSrc.getCritisRating().isEmpty())
			{
				entertainSrc.setCritisRating("No Data");
			}
			if (entertainSrc.getUserRating().isEmpty())
			{
				entertainSrc.setUserRating("No Data");
			}
			if (entertainSrc.getCategory().isEmpty())
			{
				entertainSrc.setCategory("No Data");
			}
			if (entertainSrc.getLanguage().isEmpty())
			{
				entertainSrc.setLanguage("No Data");
			}
			if (entertainSrc.getReleaseDate().isEmpty())
			{
				entertainSrc.setReleaseDate("No Data");
			}
		}
		return entertainmentSourceList;
		
	}
	
	
	public List<Entertainment> getAllEntertainment() throws JsonParseException, JsonMappingException, IOException
	{
		List<Entertainment> entertainmentList = new ArrayList<Entertainment>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getAllEntertainment";
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);	
		
		ObjectMapper mapper = new ObjectMapper();				
		entertainmentList = mapper.readValue(webServiceData, new TypeReference<List<Entertainment>>() {});
		
		return entertainmentList;
		
	}

	public List<BadmintonEventResults> getBadmintonResultByEvent(String tournamentYear) throws JsonParseException, JsonMappingException, IOException
	{
		List<BadmintonEventResults> badmintonEventResultsList = new ArrayList<BadmintonEventResults>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getBadmintonResultsForTournamentYear/"+tournamentYear;
		System.out.println("url:"+url);
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
	
		
		ObjectMapper mapper = new ObjectMapper();				
		badmintonEventResultsList = mapper.readValue(webServiceData, new TypeReference<List<BadmintonEventResults>>() {});			
		
		return badmintonEventResultsList;
		
	}
	
	public List<BadmintonEventFixures> getBadmintonFixuresByEvent(String tournamentYear) throws JsonParseException, JsonMappingException, IOException
	{
		List<BadmintonEventFixures> badmintonEventFixuresList = new ArrayList<BadmintonEventFixures>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getBadmintonFixuresForTournamentYear/"+tournamentYear;
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
			
		ObjectMapper mapper = new ObjectMapper();				
		badmintonEventFixuresList = mapper.readValue(webServiceData, new TypeReference<List<BadmintonEventFixures>>() {});			
		
		return badmintonEventFixuresList;
		
	}
	
	
	public List<BadmintonEvents> getBadmintonEvents() throws JsonParseException, JsonMappingException, IOException
	{
		List<BadmintonEvents> badmintonEventsList = new ArrayList<BadmintonEvents>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getAllBadmintonEvents";
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
			
		ObjectMapper mapper = new ObjectMapper();				
		badmintonEventsList = mapper.readValue(webServiceData, new TypeReference<List<BadmintonEvents>>() {});			
		
		return badmintonEventsList;
		
	}
	
	public List<BadmintonFixures> getAllBadmintonFixures() throws JsonParseException, JsonMappingException, IOException
	{
		List<BadmintonFixures> badmintonFixuresList = new ArrayList<BadmintonFixures>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getAllBadmintonFixures";
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
			
		ObjectMapper mapper = new ObjectMapper();				
		badmintonFixuresList = mapper.readValue(webServiceData, new TypeReference<List<BadmintonFixures>>() {});			
		
		return badmintonFixuresList;
		
	}
	
	public List<BadmintonResults> getAllBadmintonResults() throws JsonParseException, JsonMappingException, IOException
	{
		List<BadmintonResults> badmintonResultsList = new ArrayList<BadmintonResults>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getAllBadmintonResults";
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
			
		ObjectMapper mapper = new ObjectMapper();				
		badmintonResultsList = mapper.readValue(webServiceData, new TypeReference<List<BadmintonResults>>() {});			
		
		return badmintonResultsList;
		
	}
	
	public List<RegisterBadminton> getAllBadmintonRegistration() throws JsonParseException, JsonMappingException, IOException
	{
		List<RegisterBadminton> badmintonRegisterList = new ArrayList<RegisterBadminton>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getAllBadmintonRegistration";
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
			
		ObjectMapper mapper = new ObjectMapper();				
		badmintonRegisterList = mapper.readValue(webServiceData, new TypeReference<List<RegisterBadminton>>() {});			
		
		return badmintonRegisterList;
		
	}
	
	public List<DistinctBadmintonEvent> getDistinctBadmintonEvent() throws JsonParseException, JsonMappingException, IOException
	{
		List<DistinctBadmintonEvent> distinctBadmintonEventList = new ArrayList<DistinctBadmintonEvent>();
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getDistinctBadmintonEvent";
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
			
		ObjectMapper mapper = new ObjectMapper();				
		distinctBadmintonEventList = mapper.readValue(webServiceData, new TypeReference<List<DistinctBadmintonEvent>>() {});			
		
		return distinctBadmintonEventList;
		
	}
	
	public List<UserInfo> getUserInfo() throws JsonParseException, JsonMappingException, IOException
	{
		List<UserInfo> userInfoList = new ArrayList<UserInfo> ();
		
		Client client = Client.create();
		String url= "http://localhost:8080/PassUserService/restService/PassService/getalluserinfo";
		WebResource webResource = client.resource(url);
		webResource.type(MediaType.APPLICATION_JSON);		
		ClientResponse clientResponse = webResource.accept("application/json").get(ClientResponse.class);
		String webServiceData = clientResponse.getEntity(String.class);
			
		ObjectMapper mapper = new ObjectMapper();				
		userInfoList = mapper.readValue(webServiceData, new TypeReference<List<UserInfo>>() {});	
		
		
		return userInfoList;
		
	}
}
