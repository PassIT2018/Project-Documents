package com.pass.model;

import java.io.Serializable;

public class BadmintonResults implements Serializable {
	
	private String tournamentYear;
	private String eventCode;
	private String position;
	private String teamName;
	private String playerName1;
	private String playerName2;
	private String gameCode;
	private int serialNumber;
	
	
	public BadmintonResults()
	{
		this.tournamentYear = "";
		this.eventCode = "";
		this.position = "";
		this.teamName = "";
		this.playerName1 = "";
		this.playerName2 = "";
		this.gameCode = "";
		this.serialNumber = 0;
	
				
	}
	public BadmintonResults(String tournamentYear, String eventCode, String position, String teamName,
			String playerName1, String playerName2, String gameCode, int serialNumber) {
		super();
		this.tournamentYear = tournamentYear;
		this.eventCode = eventCode;
		this.position = position;
		this.teamName = teamName;
		this.playerName1 = playerName1;
		this.playerName2 = playerName2;
		this.gameCode = gameCode;
		this.serialNumber = serialNumber;
	}
	public String getTournamentYear() {
		return tournamentYear;
	}
	public void setTournamentYear(String tournamentYear) {
		this.tournamentYear = tournamentYear;
	}
	public String getEventCode() {
		return eventCode;
	}
	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}
	public String getPosition() {
		return position;
	}
	public void setPosition(String position) {
		this.position = position;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getPlayerName1() {
		return playerName1;
	}
	public void setPlayerName1(String playerName1) {
		this.playerName1 = playerName1;
	}
	public String getPlayerName2() {
		return playerName2;
	}
	public void setPlayerName2(String playerName2) {
		this.playerName2 = playerName2;
	}
	public String getGameCode() {
		return gameCode;
	}
	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}
	
	
	public int getSerialNumber() {
		return serialNumber;
	}
	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}
	@Override
	public String toString() {
		return "BadmintonResults [tournamentYear=" + tournamentYear + ", eventCode=" + eventCode + ", position="
				+ position + ", teamName=" + teamName + ", playerName1=" + playerName1 + ", playerName2=" + playerName2
				+ ", gameCode=" + gameCode + "]";
	}
	
	
	

}
