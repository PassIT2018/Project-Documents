package com.pass.model;

import java.io.Serializable;
import java.util.Date;

public class ContactUs implements Serializable {
	
	
	private static final long serialVersionUID = 1L;
	
	private int serialNumber;
	private String contactName;
	private String email;
	private String phone;
	private String message;
	private Date dateInserted;
	
	public ContactUs()
	{
		this.serialNumber = 0;
		this.contactName = "";
		this.email = "";
		this.phone = "";
		this.message = "";
		this.dateInserted = null;
	}
	
	public ContactUs(int serialNumber, String contactName, String email, String phone, String message, Date dateInserted) {
		super();
		this.serialNumber = serialNumber;
		this.contactName = contactName;
		this.email = email;
		this.phone = phone;
		this.message = message;
		this.dateInserted = dateInserted;
	}

	public int getSerialNumber() {
		return serialNumber;
	}

	public void setSerialNumber(int serialNumber) {
		this.serialNumber = serialNumber;
	}

	public String getContactName() {
		return contactName;
	}

	public void setContactName(String contactName) {
		this.contactName = contactName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Date getDateInserted() {
		return dateInserted;
	}

	public void setDateInserted(Date dateInserted) {
		this.dateInserted = dateInserted;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	@Override
	public String toString() {
		return "ContactUs [serialNumber=" + serialNumber + ", contactName=" + contactName + ", email=" + email
				+ ", phone=" + phone + ", message=" + message + ", dateInserted=" + dateInserted + "]";
	}

	

}
