package com.pass.model;

import java.io.Serializable;
import java.util.Date;

public class RegisterBadminton implements Serializable {
	
	private String tournamentYear;
	private String registrationNo;
	private String teamName;
	private String name;
	private String dob;
	private String email;
	private String phone;
	private String eventCode;
	private String partnerName;
	private String partnerDOB;
	private Double payementAmount;
	private String gameCode;
	private String dateInserted;
	private String dateUpdated;
	private int serialNo;
	
	
	public RegisterBadminton()
	{
		this.tournamentYear = "";
		this.registrationNo = "";
		this.teamName =  "";
		this.name = "";
		this.dob = null;
		this.email = "";
		this.phone = "";
		this.eventCode = "";
		this.partnerName = "";
		this.partnerDOB = null;
		this.payementAmount = 0.0;
		this.gameCode = "";
		this.dateInserted = null;
		this.dateUpdated = null;
		this.serialNo = 0;
	}
	public RegisterBadminton(String tournamentYear, String registrationNo, String teamName, String name, String dob,
			String email, String phone, String eventCode, String partnerName, String partnerDOB, Double payementAmount,
			String gameCode, String dateInserted, String dateUpdated,int serialNo) {
		super();
		this.tournamentYear = tournamentYear;
		this.registrationNo = registrationNo;
		this.teamName = teamName;
		this.name = name;
		this.dob = dob;
		this.email = email;
		this.phone = phone;
		this.eventCode = eventCode;
		this.partnerName = partnerName;
		this.partnerDOB = partnerDOB;
		this.payementAmount = payementAmount;
		this.gameCode = gameCode;
		this.dateInserted = dateInserted;
		this.dateUpdated = dateUpdated;
		this.serialNo = serialNo;
	}
	public String getTournamentYear() {
		return tournamentYear;
	}
	public void setTournamentYear(String tournamentYear) {
		this.tournamentYear = tournamentYear;
	}
	public String getRegistrationNo() {
		return registrationNo;
	}
	public void setRegistrationNo(String registrationNo) {
		this.registrationNo = registrationNo;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEventCode() {
		return eventCode;
	}
	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}
	public String getPartnerName() {
		return partnerName;
	}
	public void setPartnerName(String partnerName) {
		this.partnerName = partnerName;
	}
	public String getPartnerDOB() {
		return partnerDOB;
	}
	public void setPartnerDOB(String partnerDOB) {
		this.partnerDOB = partnerDOB;
	}
	public Double getPayementAmount() {
		return payementAmount;
	}
	public void setPayementAmount(Double payementAmount) {
		this.payementAmount = payementAmount;
	}
	public String getGameCode() {
		return gameCode;
	}
	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}
	public String getDateInserted() {
		return dateInserted;
	}
	public void setDateInserted(String dateInserted) {
		this.dateInserted = dateInserted;
	}
	public String getDateUpdated() {
		return dateUpdated;
	}
	public void setDateUpdated(String dateUpdated) {
		this.dateUpdated = dateUpdated;
	}
	
	public int getSerialNo() {
		return serialNo;
	}
	public void setSerialNo(int serialNo) {
		this.serialNo = serialNo;
	}
	@Override
	public String toString() {
		return "RegisterBadminton [tournamentYear=" + tournamentYear + ", registrationNo=" + registrationNo
				+ ", teamName=" + teamName + ", name=" + name + ", dob=" + dob + ", email=" + email + ", phone=" + phone
				+ ", eventCode=" + eventCode + ", partnerName=" + partnerName + ", partnerDOB=" + partnerDOB
				+ ", payementAmount=" + payementAmount + ", gameCode=" + gameCode + ", dateInserted=" + dateInserted
				+ ", dateUpdated=" + dateUpdated + "]";
	}
	

}
