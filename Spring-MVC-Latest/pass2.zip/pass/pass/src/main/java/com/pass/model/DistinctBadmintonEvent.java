package com.pass.model;

public class DistinctBadmintonEvent {

	private String eventCode;
	private String eventName;
	
	
	public DistinctBadmintonEvent()
	{
		this.eventCode = "";
		this.eventName = "";
	}
	public DistinctBadmintonEvent(String eventCode,String eventName) {
		super();
		this.eventCode = eventCode;
		this.eventName = eventName;
	}
	
	public String getEventCode() {
		return eventCode;
	}

	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}

	public String getEventName() {
		return eventName;
	}

	public void setEventName(String eventName) {
		this.eventName = eventName;
	}

	

	@Override
	public String toString() {
		return "DistinctBadmintonEvent [eventCode=" + eventCode + ", eventName=" + eventName + "]";
	}
	
	
	
}
