package com.pass.entertainment;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.ws.rs.core.MediaType;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.web.authentication.logout.SecurityContextLogoutHandler;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.fasterxml.jackson.core.JsonParseException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.pass.model.BadmintonEventFixures;
import com.pass.model.BadmintonEventResults;
import com.pass.model.BadmintonEvents;
import com.pass.model.BadmintonFixures;
import com.pass.model.BadmintonResults;
import com.pass.model.DistinctBadmintonEvent;
import com.pass.model.Entertainment;
import com.pass.model.EntertainmentSource;
import com.pass.model.Games;
import com.pass.model.RegisterBadminton;
import com.pass.model.UserInfo;
import com.pass.restservice.RestWebService;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
import com.sun.jersey.api.client.GenericType;
import com.sun.jersey.api.client.WebResource;




/**
 * Handles requests for the application home page.
 */

@Controller
public class HomeController {
	
	private static final Logger logger = LoggerFactory.getLogger(HomeController.class);
	
	List<String> tournamentYears = new ArrayList<String>();
	List<Games> gamesList = new ArrayList<Games>();
	List<Entertainment> entertainmentList = new ArrayList<Entertainment>();
	List<DistinctBadmintonEvent> distinctBadmintonEventList = new ArrayList<DistinctBadmintonEvent>();
	
	
	
	String currentDate = "";

	@Autowired
	RestWebService webService ;
	
	
//	The below method is used for displaying the home page. The following web services is called to display the data in the drop down list.
//	getAllGames  - This is used to get all the games from the games table
//	getAllEntertainment - This is used to get all the entertainment from the entertainment table
	
	@RequestMapping(value = "/", method = RequestMethod.GET)
	public ModelAndView home(Locale locale, Model model) {
		
		ModelAndView modelView = new ModelAndView();
		
		Date date = new Date();
		DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG,locale);
		currentDate = dateFormat.format(date);	
		
		
		
		try {
			gamesList = webService.getAllGames();
			entertainmentList = webService.getAllEntertainment();
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (Exception e) {
			
			logger.error(e.getMessage());
		}
		
						
		modelView.addObject("gamesList", gamesList);
		modelView.addObject("entertainmentList", entertainmentList);	
		modelView.setViewName("home");
		return modelView;
	}
	
//	The below method is used for displaying the badminton page. The following web services is called to display the data in the drop down list.
//	getTournamentYears  - This is used to get all the tournament years from the badminton events table;

	
	@RequestMapping(value = "/Badminton", method = RequestMethod.GET)
	public ModelAndView badminton(Model model) {
		
		ModelAndView modelView = new ModelAndView();
		try {
			tournamentYears = webService.getTournamentYear();
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (Exception e) {
			
			logger.error(e.getMessage());
		}		
		modelView.addObject("gamesList", gamesList);
		modelView.addObject("tournamentYears", tournamentYears);		
		modelView.setViewName("badminton");
		return modelView;
	}
	
	@RequestMapping(value = "/Volley Ball", method = RequestMethod.GET)
	public ModelAndView volleyBall(Locale locale, Model model) {
		
		ModelAndView modelView = new ModelAndView();
		modelView.addObject("gamesList", gamesList);
		modelView.setViewName("volleyball");
		return modelView;
	}
	
	@RequestMapping(value = "/Short Films", method = RequestMethod.GET)
	public ModelAndView shortFilm(Locale locale, Model model) {
		
		ModelAndView modelView = new ModelAndView();
		List<EntertainmentSource> shortFilmList = new ArrayList<EntertainmentSource>();
		try {
			shortFilmList = webService.getAllEntertainmentSource("E0001");
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (Exception e) {
			
			logger.error(e.getMessage());
		}
 		modelView.addObject("shortFilmList", shortFilmList);
		modelView.addObject("entertainmentList", entertainmentList);
		modelView.setViewName("shortfilm");
		return modelView;
	}
	@RequestMapping(value = "/Movie Reviews", method = RequestMethod.GET)
	public ModelAndView movieReview(Locale locale, Model model) {
		
		
		ModelAndView modelView = new ModelAndView();
		List<EntertainmentSource> movieReviewList = new ArrayList<EntertainmentSource>();
		try {
			movieReviewList = webService.getAllEntertainmentSource("E0002");
			
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (Exception e) {
			
			logger.error(e.getMessage());
		}
		modelView.addObject("movieReviewList", movieReviewList);
		modelView.addObject("entertainmentList", entertainmentList);
		modelView.setViewName("moviereview");
		return modelView;
	}
	
	@RequestMapping(value = "/badmintonfixures", method = RequestMethod.GET)
	public ModelAndView badmintonFixures(@RequestParam("year") String year,Locale locale, Model model) {
		
		List<BadmintonEventFixures> badmintonEventFixuresList = new ArrayList<BadmintonEventFixures> ();
		ModelAndView modelView = new ModelAndView();
		modelView.addObject("tournamentYears", tournamentYears);
		modelView.addObject("particularyear", year);
		modelView.addObject("gamesList", gamesList);		
		try {
			badmintonEventFixuresList = webService.getBadmintonFixuresByEvent(year);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (Exception e) {
			
			logger.error(e.getMessage());
		}		
		modelView.addObject("badmintonEventFixuresList", badmintonEventFixuresList);
		modelView.setViewName("badmintonfixures");
		return modelView;
	}
	

	
	@RequestMapping(value = "/badmintonresults", method = RequestMethod.GET)
	public ModelAndView badmintonResults(@RequestParam("year") String year,Locale locale, Model model) {
		
		List<BadmintonEventResults> badmintonEventResultsList = new ArrayList<BadmintonEventResults> ();
		
		ModelAndView modelView = new ModelAndView();
		modelView.addObject("tournamentYears", tournamentYears);
		modelView.addObject("particularyear", year);
		modelView.addObject("gamesList", gamesList);
		
		
		try {
			badmintonEventResultsList = webService.getBadmintonResultByEvent(year);
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (Exception e) {
			
			logger.error(e.getMessage());
		}
	
		modelView.addObject("badmintonEventResultsList",badmintonEventResultsList);
		modelView.setViewName("badmintonresults");
		return modelView;
	}
	
	@RequestMapping(value = "/contactus", method = RequestMethod.GET)
	public ModelAndView contactUs(Locale locale, Model model) {
		
		
		ModelAndView modelView = new ModelAndView();
		
		modelView.setViewName("contactus");
		return modelView;
	}
	
	@RequestMapping(value = "/passdb/gametable", method = RequestMethod.GET)
	public ModelAndView gametable(Locale locale, Model model) {
		
		
		ModelAndView modelView = new ModelAndView();
		try {
			gamesList = webService.getAllGames();
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		modelView.addObject("gamesList", gamesList);
		modelView.setViewName("gametable");
		return modelView;
	}
	
	@RequestMapping(value = "/passdb/entertainmenttable", method = RequestMethod.GET)
	public ModelAndView entertainmenttable(Locale locale, Model model) {
		
		
		ModelAndView modelView = new ModelAndView();
		try {
			entertainmentList = webService.getAllEntertainment();
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		modelView.addObject("entertainmentList", entertainmentList);
		modelView.setViewName("entertainmenttable");
		return modelView;
	}
	
	@RequestMapping(value = "/passdb/badmintonregistration", method = RequestMethod.GET)
	public ModelAndView badmintonRegistration(Locale locale, Model model) {
		
		
		ModelAndView modelView = new ModelAndView();
		modelView.setViewName("badmintonregistration");
		return modelView;
	}
	
	
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	public ModelAndView login(@RequestParam("status") String status, Locale locale, Model model) {
		
		ModelAndView modelView = new ModelAndView();
		
		Date date = new Date();
		
		DateFormat dateFormat = DateFormat.getDateInstance(DateFormat.LONG,locale);
		currentDate = dateFormat.format(date);
		if( status.contains("LOGIN_FAILURE"))
		{
			modelView.addObject("loginmessage", "Invalid Username / Password. Please try again");
		}
		else
		{
			modelView.addObject("loginmessage", " ");
		}
		modelView.setViewName("login");
		return modelView;
		
	}
	
	@RequestMapping(value = "/passdb/badmintoneventtable", method = RequestMethod.GET)
	public ModelAndView badmintonEvents(Locale locale, Model model) {
		
		ModelAndView modelView = new ModelAndView();
		List<BadmintonEvents> badmintonEventList = new ArrayList<BadmintonEvents>();
		
		try {
			badmintonEventList = webService.getBadmintonEvents();
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		
		
		modelView.addObject("badmintonEventList",badmintonEventList);
		modelView.addObject("distinctBadmintonEventList", distinctBadmintonEventList);
		modelView.addObject("gamesList", gamesList);
		modelView.setViewName("badmintoneventtable");
		return modelView;
		
	}
	
	@RequestMapping(value = "/passdb/badmintonfixurestable", method = RequestMethod.GET)
	public ModelAndView badmintonFixures(Locale locale, Model model) {
		
		ModelAndView modelView = new ModelAndView();
		List<BadmintonFixures> badmintonFixuresList = new ArrayList<BadmintonFixures>();
		
		try {
			badmintonFixuresList = webService.getAllBadmintonFixures();
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		
		
		modelView.addObject("badmintonFixuresList",badmintonFixuresList);
		modelView.addObject("distinctBadmintonEventList", distinctBadmintonEventList);
		modelView.addObject("gamesList", gamesList);
		modelView.setViewName("badmintonfixurestable");
		return modelView;
		
	}
	
	
	@RequestMapping(value = "/passdb/badmintonresultstable", method = RequestMethod.GET)
	public ModelAndView badmintonResults(Locale locale, Model model) {
		
		ModelAndView modelView = new ModelAndView();
		List<BadmintonResults> badmintonResultsList = new ArrayList<BadmintonResults>();
		
		try {
			badmintonResultsList = webService.getAllBadmintonResults();
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		
		
		modelView.addObject("badmintonResultsList",badmintonResultsList);
		modelView.addObject("distinctBadmintonEventList", distinctBadmintonEventList);
		modelView.addObject("gamesList", gamesList);
		
		modelView.setViewName("badmintonresultstable");
		return modelView;
		
	}
	
	
	@RequestMapping(value = "/passdb/entertainmentsourcetable", method = RequestMethod.GET)
	public ModelAndView entertainmentSource(Locale locale, Model model) {
		
		ModelAndView modelView = new ModelAndView();
		List<EntertainmentSource> entertainmentSourceList = new ArrayList<EntertainmentSource>();
		
		try {
			entertainmentSourceList = webService.getAllEntertainmentSource("All");
			entertainmentList = webService.getAllEntertainment();
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		
		
		modelView.addObject("entertainmentSourceList",entertainmentSourceList);
		modelView.addObject("entertainmentList",entertainmentList);
		
		modelView.setViewName("entertainmentsourcetable");
		return modelView;
		
	}
	
	@RequestMapping(value = "/passdb/passtables", method = RequestMethod.GET)
	public ModelAndView allTable(Locale locale, Model model) {
		
		ModelAndView modelView = new ModelAndView();
		
		try {
			distinctBadmintonEventList = webService.getDistinctBadmintonEvent();
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		
		
		modelView.setViewName("passtables");
		return modelView;
		
	}
	
	@RequestMapping(value = "/passdb/badmintonregistrationtable", method = RequestMethod.GET)
	public ModelAndView badmintionRegistrationtable(Locale locale, Model model) {
		
		ModelAndView modelView = new ModelAndView();
		List<RegisterBadminton> registerBadmintonList = new ArrayList<RegisterBadminton> ();
	
		try {
			registerBadmintonList = webService.getAllBadmintonRegistration();
			
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}

		modelView.addObject("badmintonRegistrationList", registerBadmintonList);
		modelView.addObject("distinctBadmintonEventList", distinctBadmintonEventList);
		modelView.addObject("gamesList", gamesList);
		
		
		modelView.setViewName("badmintonregistrationtable");
		return modelView;
		
	}
	
	@RequestMapping(value="/passdb/logout", method = RequestMethod.GET)
	public ModelAndView logoutPage (HttpServletRequest request, HttpServletResponse response) {
		
		ModelAndView modelView = new ModelAndView();
	    Authentication auth = SecurityContextHolder.getContext().getAuthentication();
	    if (auth != null){    
	        new SecurityContextLogoutHandler().logout(request, response, auth);
	    }
	    modelView.setViewName("redirect:/login?status=Signin");
	
	    return modelView;
	}
	
	@RequestMapping(value="/facebook", method = RequestMethod.GET)
	public ModelAndView facebook (HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelView = new ModelAndView();
	    modelView.setViewName("redirect:http://www.facebook.com");   
	    return modelView;
	}
	
	@RequestMapping(value="/twitter", method = RequestMethod.GET)
	public ModelAndView twitter(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelView = new ModelAndView();
	    modelView.setViewName("redirect:http://www.twitter.com");
	    return modelView;
	}
	
	@RequestMapping(value="/google", method = RequestMethod.GET)
	public ModelAndView google(HttpServletRequest request, HttpServletResponse response) {
		
		ModelAndView modelView = new ModelAndView();
	    modelView.setViewName("redirect:http://www.google.com");
	    return modelView;
	}
	
	@RequestMapping(value="/termsofuse", method = RequestMethod.GET)
	public ModelAndView termOfUse(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelView = new ModelAndView();
	    modelView.setViewName("termsofuse");
	    return modelView;
	}
	
	@RequestMapping(value="/passdb/userinfo", method = RequestMethod.GET)
	public ModelAndView userInfo(HttpServletRequest request, HttpServletResponse response) {

		ModelAndView modelView = new ModelAndView();
		List<UserInfo> userInfoList = new ArrayList<UserInfo> ();
		
		try {
		userInfoList = webService.getUserInfo();
		} catch (JsonParseException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (JsonMappingException e) {
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		} catch (IOException e) {			
			// TODO Auto-generated catch block
			logger.error(e.getMessage());
		}
		
		modelView.addObject("userInfoList", userInfoList);
	    modelView.setViewName("userinfo");
	    return modelView;
	}

	
}
