package com.pass.model;

import java.io.Serializable;

public class BadmintonEvents implements Serializable{
	
	private String tournamentYear;
	private String eventCode;
	private String eventName;
	private String gameCode;
	private double amount;
	
	public BadmintonEvents()
	{
		this.tournamentYear = "";
		this.eventCode = "";
		this.eventName = "";
		this.gameCode = "";
		this.amount = 0.0;
	}
	public BadmintonEvents(String tournamentYear, String eventCode, String eventName, String gameCode, double amount) {
		super();
		this.tournamentYear = tournamentYear;
		this.eventCode = eventCode;
		this.eventName = eventName;
		this.gameCode = gameCode;
		this.amount = amount;
	}
	public String getTournamentYear() {
		return tournamentYear;
	}
	public void setTournamentYear(String tournamentYear) {
		this.tournamentYear = tournamentYear;
	}
	public String getEventCode() {
		return eventCode;
	}
	public void setEventCode(String eventCode) {
		this.eventCode = eventCode;
	}
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getGameCode() {
		return gameCode;
	}
	public void setGameCode(String gameCode) {
		this.gameCode = gameCode;
	}
	public double getAmount() {
		return amount;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	@Override
	public String toString() {
		return "BadmintonEvents [tournamentYear=" + tournamentYear + ", eventCode=" + eventCode + ", eventName="
				+ eventName + ", gameCode=" + gameCode + ", amount=" + amount + "]";
	}
	
	
	

}
